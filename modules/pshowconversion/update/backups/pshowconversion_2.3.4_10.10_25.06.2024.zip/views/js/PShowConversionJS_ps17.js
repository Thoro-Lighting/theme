/* globals id_product, prestashop, combinations, attributesCombinations, trackingAdsConversionId, trackingAdsConversionLabel */

/**
 * File from https://prestashow.pl
 *
 * DISCLAIMER
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future.
 *
 *  @authors     PrestaShow.pl <contact@prestashow.pl>
 *  @copyright   2022 PrestaShow.pl
 *  @license     https://prestashow.pl/license
 */
PShowConversionJS.dataLayer.initMeasuring = function () {

    if (!PShowConversionJS.dataLayer.active) {
        return;
    }

    if (PShowConversionJS.dataLayer.debug) {
        prestashop.emit_core = prestashop.emit;
        prestashop.emit = function () {
            console.log('>> PrestaShop emitted: ' + arguments[0], arguments);
            prestashop.emit_core.apply(this, arguments);
        };
    }

    const fetchPrestaShopCart = (onSuccess = null) => {
        if (typeof prestashop.urls?.pages?.cart !== 'undefined') {
            $.ajax({
                url: prestashop.urls.pages.cart,
                data: 'ajax=1&action=update',
                method: 'GET',
                dataType: 'json',
                success: (response) => {
                    if (typeof response.cart !== 'undefined') {
                        prestashop.cart = response.cart;
                    }
                    if (onSuccess) {
                        onSuccess();
                    }
                },
            });
        }
    };
    fetchPrestaShopCart();

    const body = $('body');

    /*
     * Measuring Product Impressions
     * https://developers.google.com/tag-manager/enhanced-ecommerce#product-impressions
     */

    const gtmProducts = [];
    const listNum = [];

    $('.product-miniature').each(function () {
        const listTitle1 = $(this).closest('.products-section-title');
        const listTitle2 = $(this).closest('section').find('.section-title');
        let listTitle;
        if (listTitle1.length) {
            listTitle = listTitle1.text().trim();
        } else if (listTitle2.length) {
            listTitle = listTitle2.text().trim();
        } else {
            listTitle = body.attr('id').trim();
        }

        if (typeof listNum[listTitle] === 'undefined') {
            listNum[listTitle] = 1;
        } else {
            ++listNum[listTitle];
        }

        const productDetails = {
            'name': $(this).find('.product-title').text().trim(),
            'price': $(this).find('.product-price').text().trim()
                .replace(/([^0-9.,]+)/g, '').replace(',', '.'),
            'position': listNum[listTitle],
        };

        if (listTitle !== 'none') {
            productDetails.list = listTitle;
        }

        const id = parseInt($(this).attr('data-id-product').trim());
        if (id > 0) {
            productDetails.id = id;
        }

        if ($(this).attr('data-id-product-attribute')) {
            const variant = parseInt($(this).attr('data-id-product-attribute').trim());
            if (variant > 0) {
                productDetails.variant = variant;
            }
        }

        gtmProducts.push(productDetails);
    });

    if (gtmProducts.length) {
        let ids = [];
        // noinspection JSUnfilteredForInLoop
        for (const k in gtmProducts) {
            if (typeof gtmProducts[k].id === 'undefined') {
                continue;
            }
            if (typeof gtmProducts[k].variant === 'undefined') {
                ids.push(gtmProducts[k].id);
            } else {
                ids.push([gtmProducts[k].id, gtmProducts[k].variant]);
            }
        }

        PShowConversionJS.getProductDetails(ids, function (productDetails) {
            if (productDetails) {
                for (let k in gtmProducts) {
                    if (typeof gtmProducts[k].id === 'undefined') {
                        continue;
                    }
                    let additionalData;
                    if (typeof gtmProducts[k].variant !== 'undefined') {
                        additionalData = productDetails[gtmProducts[k].id + '-' + gtmProducts[k].variant];
                    } else {
                        additionalData = productDetails[gtmProducts[k].id];
                    }
                    gtmProducts[k] = Object.assign(gtmProducts[k], additionalData);
                }
            }

            let currency = PShowConversionJS.getCurrencyIsoCode();
            if (!currency) {
                currency = 'PLN';
            }
            const ecommerce = {'impressions': gtmProducts, 'currencyCode': currency};
            PShowConversionJS.dataLayer.push({
                'event': 'productImpressions',
                'ecommerce': ecommerce
            });
            PShowConversionJS.dataLayer.push({
                'event': 'categoryView',
                'ecommerce': ecommerce
            });
        });
    }

    /*
     * End of Measuring Product Impressions
     */

    /*
     * Measuring Views of Product Details
     * https://developers.google.com/tag-manager/enhanced-ecommerce#product-impressions
     */

    if (body.attr('id') === 'product') {

        var productContainer = $('#main[itemtype="https://schema.org/Product"]');
        if (!productContainer.length) {
            productContainer = $('#main[itemtype="http://schema.org/Product"]');
        }
        if (!productContainer.length) {
            productContainer = $('[itemtype="https://schema.org/Product"]:first');
        }
        if (!productContainer.length) {
            productContainer = $('[itemtype="http://schema.org/Product"]:first');
        }

        // prepare product details
        var productDetails = {};

        // append product id
        var productId = parseInt(body.attr('class').replace(/.*product-id-([0-9]+).*/, '$1'));
        if (!isNaN(productId)) {
            productDetails.id = productId;

            // append product price
            if (productContainer.find('[itemprop="price"]').length) {
                let price = productContainer.find('[itemprop="price"]:first').attr('content');
                if (typeof price === 'undefined') {
                    price = productContainer.find('[itemprop="price"]:first').text();
                }
                productDetails.price = price.trim().replace(/([^0-9.,]+)/, '').replace(',', '.');
            }

            // append product category
            if ($('.breadcrumb a').length) {
                productDetails.category = $('.breadcrumb a').last()
                    .closest('li').prev('li').find('a').text().trim()
                    .toLowerCase().replace(' ', '-');
            }

            if (productContainer.find('h1[itemprop="name"]').length) {
                productDetails.name = productContainer.find('h1[itemprop="name"]:first').text().trim();
            } else if (productContainer.find('[itemprop="name"]').length) {
                productDetails.name = productContainer.find('[itemprop="name"]:first').text().trim();
            }

            PShowConversionJS.dataLayer.log("displayed details of the product #" + productDetails.id);

            PShowConversionJS.getProductDetails([productDetails.id], function (_productDetails) {
                if (_productDetails) {
                    productDetails = Object.assign(productDetails, _productDetails[productDetails.id]);
                }

                let ecommerce = {
                    detail: {
                        actionField: {
                            list: 'product-page'
                        },
                        products: [productDetails]
                    }
                };

                let currency = PShowConversionJS.getCurrencyIsoCode();
                if (!currency) {
                    currency = 'PLN';
                }
                ecommerce.currencyCode = currency;

                // push events
                PShowConversionJS.dataLayer.push({
                    'event': 'productDetailImpression', 'ecommerce': ecommerce
                });
                PShowConversionJS.dataLayer.push({
                    'event': 'productView', 'ecommerce': ecommerce
                });

                // ads - dynamic remarketing
                // PShowConversionJS.dataLayer.push({
                //     'event': 'view_item',
                //     'value': productDetails.price,
                //     'items': [{
                //         'id': productDetails.id,
                //         'google_business_vertical': 'retail'
                //     }]
                // });
            })
        }
    }

    /*
     * End of Measuring Views of Product Details
     */

    /*
     * Measuring Product Clicks
     */

    $(document).on('click', '.product-miniature a', function (e) {

        // if clicked link should redirect to other url, then prevent redirection, send event and then do the redirection
        const isRedirectionLink = !$(this).hasClass('gmlightbox'); // Ticket #937325

        const productUrl = $(this).attr('href').trim();

        if (isRedirectionLink) {
            e.preventDefault();

            // give half second for script to push event and redirect
            setTimeout(function () {
                document.location = productUrl;
            }, 500);
        }

        const productContainer = $(this).closest('.product-miniature');

        // prepare product details
        let productDetails = {
            'name': productContainer.find('.product-title').text().trim(),
            'id': productContainer.attr('data-id-product'),
            'variant': productContainer.attr('data-id-product-attribute'),
            'price': productContainer.find('.product-price').text().trim()
                .replace(/([^0-9\.\,]+)/g, '').replace(',', '.')
        };

        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log("clicked on product " + productDetails.name);
            PShowConversionJS.dataLayer.log(productDetails);
        }

        let ids = [productContainer.attr('data-id-product')];
        if (productContainer.attr('data-id-product-attribute').length &&
            parseInt(productContainer.attr('data-id-product-attribute'))) {
            ids = [[
                productContainer.attr('data-id-product'),
                productContainer.attr('data-id-product-attribute')
            ]];
        }

        let listTitle = $(this).closest('.products-section-title');
        if (listTitle.length) {
            listTitle = listTitle.text().trim();
        } else {
            listTitle = body.attr('id').trim();
        }

        PShowConversionJS.getProductDetails(ids, function (_productDetails) {
            if (_productDetails) {
                let ids = productContainer.attr('data-id-product');
                if (productContainer.attr('data-id-product-attribute').length &&
                    parseInt(productContainer.attr('data-id-product-attribute'))) {
                    ids += '-' + productContainer.attr('data-id-product-attribute');
                }
                productDetails = Object.assign(productDetails, _productDetails[ids]);
            }

            const ecommerce = {
                'click': {
                    'actionField': {
                        'list': listTitle
                    },
                    'products': [productDetails]
                }
            };

            let currency = PShowConversionJS.getCurrencyIsoCode();
            if (!currency) {
                currency = 'PLN';
            }
            ecommerce.currencyCode = currency;

            const fullData = {
                'event': 'productClick',
                'ecommerce': ecommerce,
                'eventCallback': function () {
                    // redirect to the product page
                    document.location = productUrl;
                }
            };

            // push event
            PShowConversionJS.dataLayer.push(fullData);
        });

        if (isRedirectionLink) {
            return false;
        }
    });

    /*
     * End of Measuring Product Clicks
     */

    /*
     * Measuring Additions to a Shopping Cart
     */

    // save current shopping cart details

    fetchPrestaShopCart(() => {
        PShowConversionJS.shopping_cart = prestashop.cart.products;
    });

    prestashop.addListener('updateCart', function (data) {
        if (typeof PShowConversionJS.shopping_cart[Symbol.iterator] !== 'function') {
            PShowConversionJS.shopping_cart = [];
        }
        const previousCart = [...PShowConversionJS.shopping_cart];
        fetchPrestaShopCart(() => {
            PShowConversionJS.shopping_cart = prestashop.cart.products;
        });

        let productId = parseInt(
            data?.resp?.id_product
            || data?.reason?.productId
            || data?.reason?.idProduct
            || data?.reason?.id_product
            || 0
        );
        let productAttributeId = parseInt(
            data?.resp?.id_product_attribute
            || data?.reason?.productAttributeId
            || data?.reason?.idProductAttribute
            || data?.reason?.id_product_attribute
            || 0
        );
        // console.info('updateCart', productId, productAttributeId, data);

        if (!productId) {
            PShowConversionJS.dataLayer.warn('updateCart: no product id found');
            return;
        }

        let currentCart = data?.resp?.cart;
        let processOnCurrentCart = (onSuccess) => onSuccess();
        if (!currentCart) {
            processOnCurrentCart = fetchPrestaShopCart;
        } else {
            prestashop.cart = currentCart;
        }

        processOnCurrentCart(() => {
            currentCart = prestashop.cart;

            let product = null;

            // find product in the shopping cart
            for (let i in currentCart.products) {
                if (
                    parseInt(currentCart.products[i].id_product) === productId
                    && (
                        !productAttributeId
                        || parseInt(currentCart.products[i].id_product_attribute) === productAttributeId
                    )
                ) {
                    product = currentCart.products[i];
                    break;
                }
            }

            // find product in the shopping cart cache
            let productCache = null;
            for (let i in previousCart) {
                if (
                    parseInt(previousCart[i].id_product) === productId
                    && (
                        !productAttributeId
                        || parseInt(previousCart[i].id_product_attribute) === productAttributeId
                    )
                ) {
                    productCache = previousCart[i];
                    break;
                }
            }
            if (product) {
                const ids = [[product.id_product, product?.id_product_attribute || 0]];

                let productDetails = {
                    'name': product.name,
                    'id': product.id_product,
                    'variant': product?.id_product_attribute,
                    'price': product.price,
                    'quantity': product.cart_quantity,
                };

                PShowConversionJS.getProductDetails(ids, function (_productDetails) {
                    if (_productDetails) {
                        for (let ids in _productDetails) {
                            productDetails = Object.assign(productDetails, _productDetails[ids]);
                            break;
                        }
                    }

                    productDetails['quantity'] = parseInt(product.cart_quantity);

                    const fullData = {};
                    let ecommerce = {
                        'remove': {
                            'products': [productDetails]
                        }
                    };
                    fullData.event = 'removeFromCart';
                    if (
                        productCache === null
                        || parseInt(productCache.cart_quantity) < parseInt(product.cart_quantity)
                    ) {
                        fullData.event = 'addToCart';
                        ecommerce = {
                            'add': {
                                'products': [productDetails]
                            }
                        };
                    }

                    let currency = PShowConversionJS.getCurrencyIsoCode();
                    if (!currency) {
                        currency = 'PLN';
                    }
                    ecommerce.currencyCode = currency;
                    fullData['ecommerce'] = ecommerce;

                    // push event
                    PShowConversionJS.dataLayer.push(fullData);

                    // ads - dynamic remarketing
                    // PShowConversionJS.dataLayer.push({
                    //     'event': 'add_to_cart',
                    //     'value': product.price,
                    //     'items': [{
                    //         'id': product.id_product,
                    //         'google_business_vertical': 'custom'
                    //     }]
                    // });
                });
            } else {
                PShowConversionJS.dataLayer.warn('updateCart: no product found');
            }
        });
    });

    /*
     * End of Measuring Additions to a Shopping Cart
     */

    PShowConversionJS.getCheckoutStep = function () {

        let checkoutStep = 0;

        switch ($('.js-current-step').attr('id')) {
            case 'checkout-personal-information-step':
                checkoutStep = 1;
                break;
            case 'checkout-addresses-step':
                checkoutStep = 2;
                break;
            case 'checkout-delivery-step':
                checkoutStep = 3;
                break;
            case 'checkout-payment-step':
                checkoutStep = 4;
                break;
        }

        if (!checkoutStep) {
            if ($('#checkout-personal-information-step').hasClass('-current')) {
                checkoutStep = 1;
            } else if ($('#checkout-addresses-step').hasClass('-current')) {
                checkoutStep = 2;
            } else if ($('#checkout-delivery-step').hasClass('-current')) {
                checkoutStep = 3;
            } else if ($('#checkout-payment-step').hasClass('-current')) {
                checkoutStep = 4;
            }
        }

        if (PShowConversionJS.dataLayer.controller === 'cart') {
            checkoutStep = 1;
        }

        if (PShowConversionJS.dataLayer.controller === 'orderconfirmation' &&
            PShowConversionJS.dataLayer.order !== null) {
            checkoutStep = 5;
        }

        return checkoutStep;
    };

    /**
     * Measuring Checkout Options
     * https://developers.google.com/tag-manager/enhanced-ecommerce#checkout_option
     */
    const deliveryOptionRadio = $('.delivery-option input[type="radio"]');
    if (deliveryOptionRadio.length) {
        const nameOfDeliveryOptionRadio = deliveryOptionRadio.attr('name');

        $(document).on('change', 'input[name="' + nameOfDeliveryOptionRadio + '"]', function () {

            const checkoutStep = PShowConversionJS.getCheckoutStep();

            if (PShowConversionJS.dataLayer.debug) {
                PShowConversionJS.dataLayer.log("changed shipping method");
            }

            const optionValue = $('label[for="' + $(this).attr('id') + '"] .carrier-name').text().trim();

            const checkoutOption = {
                'event': 'checkoutOption',
                'ecommerce': {
                    'checkoutOption': {
                        'actionField': {
                            'step': checkoutStep,
                            'option': optionValue
                        }
                    }
                }
            };

            PShowConversionJS.dataLayer.push(checkoutOption);
        });
    }

    $(document).on('change', 'input[name="payment-option"]', function () {

        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log("selected payment method");
        }

        const checkoutStep = PShowConversionJS.getCheckoutStep();

        const optionValue = $('label[for="' + $(this).attr('id') + '"]').text().trim();

        const checkoutOption = {
            'event': 'checkoutOption',
            'ecommerce': {
                'checkoutOption': {
                    'actionField': {
                        'step': checkoutStep,
                        'option': optionValue
                    }
                }
            }
        };

        PShowConversionJS.dataLayer.push(checkoutOption);
    });

    /**
     * End of Measuring Checkout Options
     */

    const isOrderConfirmationPageWithOrder = (
        PShowConversionJS.dataLayer.controller === 'orderconfirmation'
        && PShowConversionJS.dataLayer.order !== null
    );

    /**
     * Measuring Checkout Steps
     * https://developers.google.com/tag-manager/enhanced-ecommerce#checkout_option
     */

    if (
        body.attr('id') === 'checkout'
        || isOrderConfirmationPageWithOrder
        || PShowConversionJS.dataLayer.controller === 'cart'
    ) {

        fetchPrestaShopCart(() => {
            const checkout = {
                'event': 'checkout',
                'ecommerce': {
                    'checkout': {
                        'actionField': {
                            'step': PShowConversionJS.getCheckoutStep(),
                        }
                    }
                }
            };

            let currency = PShowConversionJS.getCurrencyIsoCode();
            if (!currency) {
                currency = 'PLN';
            }
            checkout.currencyCode = currency;

            let ids = [];
            for (let i in prestashop.cart.products) {
                const item = prestashop.cart.products[i];
                let id = item.id_product;
                if (typeof item.id_product_attribute !== undefined && parseInt(item.id_product_attribute) > 0) {
                    id = [item.id_product, item.id_product_attribute];
                }
                ids.push(id);
            }

            PShowConversionJS.getProductDetails(ids, function (productDetails) {
                checkout.ecommerce.checkout.products = [];
                for (let x in productDetails) {
                    productDetails[x].quantity = 1;
                    for (let i in prestashop.cart.products) {
                        const cartProduct = prestashop.cart.products[i];
                        if (cartProduct.id_product === productDetails[x].id) {
                            productDetails[x].quantity = cartProduct.quantity;
                            break;
                        }
                    }
                    checkout.ecommerce.checkout.products.push(productDetails[x]);
                }

                PShowConversionJS.dataLayer.push(checkout);
            });
        });
    }

    /**
     * End of Measuring Checkout Steps
     */

    /**
     * Measuring Purchases
     * https://developers.google.com/tag-manager/enhanced-ecommerce#purchases
     */

    if (isOrderConfirmationPageWithOrder) {
        const transactionId = PShowConversionJS.dataLayer.order['actionField']['id'];

        const cookieName = 'GTMdl_purchase_' + transactionId;
        if (PShowConversionJS.cookie.get(cookieName) !== null) {
            return;
        }
        PShowConversionJS.cookie.set(cookieName, '1', 7);

        PShowConversionJS.dataLayer.push({
            'event': 'purchase',
            'ecommerce': {
                'purchase': PShowConversionJS.dataLayer.order
            }
        });

        if (typeof trackingAdsConversionId !== 'undefined' && typeof trackingAdsConversionLabel !== 'undefined') {
            PShowConversionJS.dataLayer.push(
                'event',
                'conversion',
                {
                    'send_to': trackingAdsConversionId + '/' + trackingAdsConversionLabel,
                    'value': PShowConversionJS.dataLayer.order['actionField']['revenue'],
                    'currency': 'PLN',
                    'transaction_id': transactionId
                }
            );
        }
    }

    /**
     * End of Measuring Purchases
     */

};
