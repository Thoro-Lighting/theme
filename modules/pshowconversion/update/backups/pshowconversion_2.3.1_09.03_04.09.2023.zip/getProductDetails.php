<?php

require_once dirname(__FILE__) . '/../../config/config.inc.php';

if (isset($_SERVER['HTTP_SEC_FETCH_SITE']) && $_SERVER['HTTP_SEC_FETCH_SITE'] != 'same-origin') {
    http_response_code(404);
    die();
}

$ids = (array)json_decode(Tools::getValue('id'));
if (!$ids) {
    http_response_code(404);
    exit;
}

$context = Context::getContext();
$context->cart = new Cart();

$sql = 'SELECT pl.`name`, m.`name` AS manufacturer_name, cl.`name` as category_name
        FROM `' . _DB_PREFIX_ . 'product` p 
        JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON (p.`id_product` = pl.`id_product`)
        LEFT JOIN `' . _DB_PREFIX_ . 'category_lang` cl ON (p.`id_category_default` = cl.`id_category` AND cl.`id_lang` = pl.`id_lang`) 
        LEFT JOIN `' . _DB_PREFIX_ . 'manufacturer` m ON (p.`id_manufacturer` = m.`id_manufacturer`) 
        WHERE p.`id_product` = %d AND pl.`id_lang` = %d';
$sqlAttributes = 'SELECT agl.`name` AS name, al.`name` AS val
        FROM `' . _DB_PREFIX_ . 'product_attribute_combination` pac 
        JOIN `' . _DB_PREFIX_ . 'attribute` a ON (pac.`id_attribute` = a.`id_attribute`)
        JOIN `' . _DB_PREFIX_ . 'attribute_group_lang` agl ON (agl.`id_attribute_group` = a.`id_attribute_group`)
        JOIN `' . _DB_PREFIX_ . 'attribute_lang` al ON (al.`id_attribute` = a.`id_attribute`)
        WHERE pac.`id_product_attribute` = %d AND agl.`id_lang` = %d AND al.`id_lang` = %d';

$result = [];

$limit = 50;
foreach ($ids as $id) {
    if (--$limit < 0) {
        break;
    }

    if (is_array($id)) {
        list($id_product, $id_product_attribute) = $id;
    } else {
        $id_product = $id;
        $id_product_attribute = '';
    }

    $data = Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow(
        sprintf($sql, $id_product, $context->language->id)
    );
    $variant = '';
    if ($id_product_attribute) {
        $attributes = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(
            sprintf($sqlAttributes, $id_product, $id_product_attribute, $context->language->id, $context->language->id)
        );
        $variant = [];
        foreach ($attributes as $attr) {
            $variant[] = sprintf('%s: %s', $attr['name'], $attr['val']);
        }
        $variant = implode(', ', $variant);
    }

    $price = Product::getPriceStatic($id_product, true, $id_product_attribute, 2);

    $result[$id_product . ($id_product_attribute ? ('-' . $id_product_attribute) : null)] = [
        'id' => $id_product,
        'variant' => $variant,
        'name' => $data['name'],
        'price' => $price,
        'brand' => $data['manufacturer_name'],
        'category' => $data['category_name'],
    ];
}

echo json_encode($result);
exit;