<?php

die();

//use PShowConversion\Service\MeasurementProtocolService;
//
//require_once dirname(__FILE__) . '/../../config/config.inc.php';
//require_once dirname(__FILE__) . '/config.php';
//
//Context::getContext()->shop = Shop::initialize();
//Context::getContext()->cart = new Cart();
//Cache::clean('*');
//
//$orderId = 5;
//
//$result = MeasurementProtocolService::getInstance()->hitPurchase($orderId, null, true);
//
//var_dump($result);
//die();