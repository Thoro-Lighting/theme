/* global id_product, combinations, attributesCombinations, trackingAdsConversionId, trackingAdsConversionLabel */

/**
 * File from https://prestashow.pl
 *
 * DISCLAIMER
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future.
 *
 *  @authors     PrestaShow.pl <contact@prestashow.pl>
 *  @copyright   2018 PrestaShow.pl
 *  @license     https://prestashow.pl/license
 */

PShowConversionJS.dataLayer.productListImpressionInterval = function (listObj, listId) {

    if (!listObj.is(':visible')) {
        return;
    }

    clearInterval(PShowConversionJS.dataLayer.intervals[listId]);

    var gtmProducts = [];

    var bodyId = $('body').attr('id');

    var listName = '';
    if (bodyId && bodyId === 'search') {
        listName = 'Search results';
    } else if (typeof listId !== 'undefined' && listId.length) {
        listName = listId;
    }

    var products = listObj.find('.product-container');

    if (PShowConversionJS.dataLayer.debug) {
        PShowConversionJS.dataLayer.log(
            "found " + products.length
            + " products on the list: " + listName
        );
    }

    var position = 0;
    if (listObj.parents('.center_column').length && bodyId !== 'index') {
        position = PShowConversionJS.dataLayer.currentPage * PShowConversionJS.dataLayer.ps_products_per_page;
    }

    products.each(function () {

        ++position;

        var productDetails = {
            'name': $(this).find('[itemprop="name"]').text().trim(),
            'price': $(this).find('[itemprop="price"]').text().trim()
                .replace(/([^0-9\.\,]+)/g, '').replace(',', '.'),
            'position': position
        };

        if (listName) {
            productDetails.list = listName;
        }

        gtmProducts.push(productDetails);

    });

    var fullData = {'event': 'impressions', 'ecommerce': {'impressions': gtmProducts}};

    PShowConversionJS.dataLayer.push(fullData);

    // ads - dynamic remarketing
    // PShowConversionJS.dataLayer.push({
    //     'event': 'view_item_list',
    //     'items': gtmProducts
    // });

};

PShowConversionJS.dataLayer.initMeasuring = function () {

    if (!PShowConversionJS.dataLayer.active) {
        return;
    }

    // try to get page from request uri
    PShowConversionJS.dataLayer.currentPage = parseInt(document.location.href.replace(/.*p=([0-9]+).*/, '$1'));
    if (isNaN(PShowConversionJS.dataLayer.currentPage)) {
        // try to get page from url hash
        PShowConversionJS.dataLayer.currentPage = parseInt(document.location.href.replace(/.*page-([0-9]+).*/, '$1'));
    }
    if (isNaN(PShowConversionJS.dataLayer.currentPage)) {
        // set default page
        PShowConversionJS.dataLayer.currentPage = 1;
    }
    PShowConversionJS.dataLayer.currentPage -= 1;


    /*
     * Measuring Product Impressions
     * https://developers.google.com/tag-manager/enhanced-ecommerce#product-impressions
     */
    var productLists = $('.product_list');

    if (productLists.length) {

        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log("found " + productLists.length + " product lists");
        }

        var listNum = 0;

        productLists.each(function () {

            ++listNum;

            var listObj = $(this);
            var listId = listObj.attr('id');

            if (!listId) {
                listId = $('body').attr('id') + "_listnum_" + listNum;
            }

            PShowConversionJS.dataLayer.intervals[listId] = setInterval(function () {
                PShowConversionJS.dataLayer.productListImpressionInterval(listObj, listId);
            }, 3000);

        });

    }
    /*
     * End of Measuring Product Impressions
     */

    /*
     * Measuring Views of Product Details
     * https://developers.google.com/tag-manager/enhanced-ecommerce#product-impressions
     */
    if ($('body').attr('id') === 'product') {

        var productContainer = $('#main[itemtype="https://schema.org/Product"]');
        if (!productContainer.length) {
            productContainer = $('#main[itemtype="http://schema.org/Product"]');
        }
        if (!productContainer.length) {
            productContainer = $('[itemtype="https://schema.org/Product"]:first');
        }
        if (!productContainer.length) {
            productContainer = $('[itemtype="http://schema.org/Product"]:first');
        }

        // prepare product details
        var productDetails = {};

        // append product name
        if (productContainer.find('h1[itemprop="name"]').length) {
            productDetails.name = productContainer.find('h1[itemprop="name"]:first').text().trim();
        } else if (productContainer.find('[itemprop="name"]').length) {
            productDetails.name = productContainer.find('[itemprop="name"]:first').text().trim();
        }

        // append product id
        var productId = parseInt($('body').attr('class').replace(/.*product\-([0-9]+).*/, '$1'));
        if (isNaN(productId) && typeof id_product !== 'undefined' && !isNaN(id_product)) {
            productId = id_product;
        }
        if (!isNaN(productId)) {
            productDetails.id = productId;

            // append product price
            if (productContainer.find('[itemprop="price"]').length) {
                var price = productContainer.find('[itemprop="price"]:first').attr('content');
                if (typeof price === 'undefined') {
                    price = productContainer.find('[itemprop="price"]:first').text();
                }
                productDetails.price = price.trim().replace(/([^0-9.,]+)/, '').replace(',', '.');
            }

            // append product category
            if ($('.breadcrumb a').length) {
                productDetails.category = $('.breadcrumb a').last()
                    .closest('li').prev('li').find('a').text().trim()
                    .toLowerCase().replace(' ', '-');
            }

            if (PShowConversionJS.dataLayer.debug) {
                PShowConversionJS.dataLayer.log("displayed details of the product #" + productDetails.id);
            }

            PShowConversionJS.getProductDetails([productDetails.id], function (_productDetails) {
                if (_productDetails) {
                    productDetails = Object.assign(productDetails, _productDetails[productDetails.id]);
                }

                var ecommerce = {
                    'detail': {
                        'actionField': {
                            'list': 'product-page'
                        },
                        'products': [productDetails]
                    }
                };
                var currency = PShowConversionJS.getCurrencyIsoCode();
                if (currency) {
                    ecommerce.currencyCode = currency;
                }

                var fullData = {
                    'event': 'productDetailImpression', 'ecommerce': ecommerce
                };

                // push event
                PShowConversionJS.dataLayer.push(fullData);

                // ads - dynamic remarketing
                // PShowConversionJS.dataLayer.push({
                //     'event': 'view_item',
                //     'value': productDetails.price,
                //     'items': [{
                //         'id': productDetails.id,
                //         'google_business_vertical': 'retail'
                //     }]
                // });
            });

            // var fullData = {
            //     'event': 'detail', 'ecommerce': {'detail': {'products': [productDetails]}}
            // };
            //
            // // push event
            // PShowConversionJS.dataLayer.push(fullData);

            // ads - dynamic remarketing
            // PShowConversionJS.dataLayer.push({
            //     'event': 'view_item',
            //     'value': productDetails.price,
            //     'items': [{
            //         'id': productDetails.id,
            //         'google_business_vertical': 'retail'
            //     }]
            // });

        }
    }
    /*
     * End of Measuring Views of Product Details
     */

    /*
     * Measuring Product Clicks
     * https://developers.google.com/tag-manager/enhanced-ecommerce#product-clicks
     */
    $(document).on('click', '.product-container a:not(.quick-view):not(.ajax_add_to_cart_button)', function (e) {

        e.preventDefault();

        const productUrl = $(this).attr('href').trim();

        // give some time for script to push event and redirect
        setTimeout(function () {
            document.location = productUrl;
        }, 150);

        var productContainer = $(this).closest('.product-container');
        if (!productContainer.length) {
            productContainer = $('#main[itemtype="https://schema.org/Product"]');
        }
        if (!productContainer.length) {
            productContainer = $('#main[itemtype="http://schema.org/Product"]');
        }
        if (!productContainer.length) {
            productContainer = $('[itemtype="https://schema.org/Product"]:first');
        }
        if (!productContainer.length) {
            productContainer = $('[itemtype="http://schema.org/Product"]:first');
        }

        if (productContainer.find('h1[itemprop="name"]').length) {
            productName = productContainer.find('h1[itemprop="name"]:first').text().trim();
        } else if (productContainer.find('[itemprop="name"]').length) {
            productName = productContainer.find('[itemprop="name"]:first').text().trim();
        } else {
            return;
        }

        // find position of the clicked item
        var position = parseInt(productContainer.index('.product-container')) + 1;
        position += PShowConversionJS.dataLayer.currentPage * PShowConversionJS.dataLayer.ps_products_per_page;

        // prepare product details
        var productDetails = {
            'name': productName,
            'id': productUrl.replace(/.*id_product=([0-9]+).*/, '$1'),
            'price': productContainer.find('[itemprop="price"]').text().trim()
                .replace(/([^0-9\.\,]+)/g, '').replace(',', '.'),
            'position': position,
        };
        if (isNaN(productDetails.id)) {
            productDetails.id = productUrl.replace(/.*([0-9]+).*\.html/, '$1');
        }

        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log("clicked on product " + productDetails.name);
            PShowConversionJS.dataLayer.log(productDetails);
        }

        var fullData = {
            'event': 'productClick',
            'ecommerce': {'click': {'products': [productDetails]}},
            'eventCallback': function () {
                // redirect to the product page
                // document.location = productUrl;
            }
        };

        // push event
        PShowConversionJS.dataLayer.push(fullData);

        return false;
    });
    /*
     * End of Measuring Product Clicks
     */

    /*
     * Measuring Additions to a Shopping Cart
     * https://developers.google.com/tag-manager/enhanced-ecommerce#add
     */
    $(document).on('click', '.ajax_add_to_cart_button', function (e) {


        // var productContainer = $(this).closest('.product-container');
        var productContainer = $('#main[itemtype="https://schema.org/Product"]');
        if (!productContainer.length) {
            productContainer = $('#main[itemtype="http://schema.org/Product"]');
        }
        if (!productContainer.length) {
            productContainer = $('[itemtype="https://schema.org/Product"]:first');
        }
        if (!productContainer.length) {
            productContainer = $('[itemtype="http://schema.org/Product"]:first');
        }

        const btn = $(this);

        let productUrl = '';
        if (btn.prop("tagName") === 'A') {
            productUrl = $(this).attr('href')?.trim() ?? '';
        } else {
            productUrl = productContainer.find(".lnk_view")?.attr('href')?.trim() ?? '';
        }

        if (productContainer.find('h1[itemprop="name"]').length) {
            productName = productContainer.find('h1[itemprop="name"]:first').text().trim();
        } else if (productContainer.find('[itemprop="name"]').length) {
            productName = productContainer.find('[itemprop="name"]:first').text().trim();
        } else {
            return;
        }

        // prepare product details
        var productDetails = {
            'name': productName,
            'id': productUrl.replace(/.*id_product=([0-9]+).*/, '$1'),
            'price': productContainer.find('[itemprop="price"]').text().trim()
                .replace(/([^0-9\.\,]+)/, '').replace(',', '.'),
            'quantity': 1
        };
        if (isNaN(productDetails.id)) {
            productDetails.id = productUrl.replace(/.*([0-9]+).*\.html/, '$1');
        }

        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log("added product to cart " + productDetails.id);
        }

        var fullData = {
            'event': 'addToCart',
            'ecommerce': {'add': {'products': [productDetails]}}
        };

        // push event
        PShowConversionJS.dataLayer.push(fullData);

        // ads - dynamic remarketing
        // PShowConversionJS.dataLayer.push({
        //     'event': 'add_to_cart',
        //     'value': productDetails.price,
        //     'items': [{
        //         'id': productDetails.id,
        //         'google_business_vertical': 'custom'
        //     }]
        // });

    });
    $(document).on('click', '#add_to_cart input, #add_to_cart button', function (e) {

        // var productContainer = $(this).closest('.product-container');
        var productContainer = $('#main[itemtype="https://schema.org/Product"]');
        if (!productContainer.length) {
            productContainer = $('#main[itemtype="http://schema.org/Product"]');
        }
        if (!productContainer.length) {
            productContainer = $('[itemtype="https://schema.org/Product"]:first');
        }
        if (!productContainer.length) {
            productContainer = $('[itemtype="http://schema.org/Product"]:first');
        }

        if (productContainer.find('h1[itemprop="name"]').length) {
            productName = productContainer.find('h1[itemprop="name"]:first').text().trim();
        } else if (productContainer.find('[itemprop="name"]').length) {
            productName = productContainer.find('[itemprop="name"]:first').text().trim();
        } else {
            return;
        }

        // prepare product details
        var productDetails = {
            'name': productName,
            'id': $('#product_page_product_id').val(),
            'price': productContainer.find("[itemprop=\"price\"]").eq(0).text().trim()
                .replace(/([^0-9\.\,]+)/, '').replace(',', '.'),
            'quantity': productContainer.find('#quantity_wanted').val()
        };

        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log("added product to cart " + productDetails.id);
        }

        // find selected combination and
        // prepare variant string (selected attributes separated by comma and space)
        var idCombination = parseInt($('#idCombination').val());
        if (!isNaN(idCombination) && idCombination &&
            (typeof combinations !== 'undefined' &&
                typeof attributesCombinations !== 'undefined')) {

            // find id's of the selected attributes
            var idsAttributes = [];
            for (var x in combinations) {
                if (parseInt(combinations[x].idCombination) === idCombination) {
                    idsAttributes = combinations[x].idsAttributes;
                    break;
                }
            }

            if (idsAttributes.length) {
                productDetails.variant = '';

                for (var x in idsAttributes) {
                    for (var y in attributesCombinations) {
                        if (parseInt(idsAttributes[x]) === parseInt(attributesCombinations[y].id_attribute)) {
                            productDetails.variant += attributesCombinations[y].attribute.ucfirst() + ', ';
                            break;
                        }
                    }
                }

                productDetails.variant = productDetails.variant.trim();
                productDetails.variant = productDetails.variant.substr(0, (productDetails.variant.length - 1));
            }
        }

        var fullData = {
            'event': 'addToCart',
            'ecommerce': {'add': {'products': [productDetails]}}
        };

        // push event
        PShowConversionJS.dataLayer.push(fullData);

        // ads - dynamic remarketing
        // PShowConversionJS.dataLayer.push({
        //     'event': 'add_to_cart',
        //     'value': productDetails.price,
        //     'items': [{
        //         'id': productDetails.id,
        //         'google_business_vertical': 'custom'
        //     }]
        // });

    });
    $(document).on('click', '.cart_quantity_up', function (e) {

        // find product id
        var productId = parseInt($(this).attr('id').replace('cart_quantity_up_', ''));

        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log("changed quantity (+1) for product " + productId);
        }

        // prepare product details
        var productDetails = {
            'id': productId,
            'quantity': 1
        };

        var fullData = {
            'event': 'addToCart',
            'ecommerce': {'add': {'products': [productDetails]}}
        };

        // push event
        PShowConversionJS.dataLayer.push(fullData);

        // ads - dynamic remarketing
        // PShowConversionJS.dataLayer.push({
        //     'event': 'add_to_cart',
        //     'value': productDetails.price,
        //     'items': [{
        //         'id': productDetails.id,
        //         'google_business_vertical': 'custom'
        //     }]
        // });

    });
    /*
     * End of Measuring Additions to a Shopping Cart
     */

    /*
     * Measuring Removals from a Shopping Cart
     * https://developers.google.com/tag-manager/enhanced-ecommerce#add
     */
    $(document).on('click', '.ajax_cart_block_remove_link', function (e) {

        // customized product management
        var customizationId = 0;
        var productId = 0;
        var customizableProductDiv = $($(this).parent().parent())
            .find("div[id^=devareCustomizableProduct_]");

        if (customizableProductDiv && $(customizableProductDiv).length) {
            $(customizableProductDiv).each(function () {
                var ids = $(this).attr('id').split('_');
                if (typeof (ids[1]) !== 'undefined') {
                    customizationId = parseInt(ids[1]);
                    productId = parseInt(ids[2]);
                    return false;
                }
            });
        }

        // common product management
        if (!customizationId) {
            try {
                // retrieve idProduct and idCombination from the displayed product in the block cart
                var firstCut = $(this).parent().parent()
                    .attr('id').replace('cart_block_product_', '');
                firstCut = firstCut.replace('devareCustomizableProduct_', '');
                ids = firstCut.split('_');
                productId = parseInt(ids[0]);
            } catch (e) {
                PShowConversionJS.dataLayer.error(e);
            }
        }

        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log("removed product from cart " + productId);
        }

        // prepare product details
        var productDetails = {
            'id': productId
        };

        var productQty = parseInt($($(this).parent().parent())
            .find(".quantity").text());
        if (!isNaN(productQty) && productQty > 0) {
            productDetails.quantity = productQty;
        }

        productDetails.variant = $($(this).parent().parent()).find(".product-atributes").text().trim();

        var fullData = {
            'event': 'removeFromCart',
            'ecommerce': {'remove': {'products': [productDetails]}}
        };

        // push event
        PShowConversionJS.dataLayer.push(fullData);

    });
    $(document).on('click', '.cart_quantity_devare', function (e) {

        // find product id
        var productId = parseInt($(this).attr('id'));

        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log("removed product from cart " + productId);
        }

        // prepare product details
        var productDetails = {
            'id': productId
        };

        var fullData = {
            'event': 'removeFromCart',
            'ecommerce': {'remove': {'products': [productDetails]}}
        };

        // push event
        PShowConversionJS.dataLayer.push(fullData);

    });
    $(document).on('click', '.cart_quantity_down', function (e) {

        // find product id
        var productId = parseInt($(this).attr('id').replace('cart_quantity_down_', ''));

        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log("changed quantity (-1) for product " + productId);
        }

        // prepare product details
        var productDetails = {
            'id': productId,
            'quantity': 1
        };

        var fullData = {
            'event': 'removeFromCart',
            'ecommerce': {'remove': {'products': [productDetails]}}
        };

        // push event
        PShowConversionJS.dataLayer.push(fullData);

    });
    /*
     * End of Measuring Removals from a Shopping Cart
     */

    /*
     * Measuring Additions and Removals from a Shopping Cart
     * https://developers.google.com/tag-manager/enhanced-ecommerce#add
     */
    $(document).on('focusin', '.cart_quantity_input', function (e) {
        // save current value
        $(this).data('val', $(this).val());

        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log("saved current quantity: " + $(this).val());
        }
    });
    $(document).on('change', '.cart_quantity_input', function (e) {

        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log("changed quantity to: " + $(this).val());
        }

        // find product id
        var productId = parseInt($(this).attr('name').replace('quantity_', ''));

        // find quantities
        var newQty = parseInt($(this).val());
        var oldQty = parseInt($(this).data('val'));
        var difference = Math.abs(newQty - oldQty);
        if (!difference) {
            return;
        }

        // prepare product details
        var productDetails = {
            'id': productId,
            'quantity': difference
        };

        var fullData = {
            'event': ((newQty > oldQty) ? 'addToCart' : 'removeFromCart'),
            'ecommerce': ((newQty > oldQty) ?
                    {'add': {'products': [productDetails]}} :
                    {'remove': {'products': [productDetails]}}
            )
        };

        // push event
        PShowConversionJS.dataLayer.push(fullData);

    });
    /*
     * End of Measuring Removals from a Shopping Cart
     */

    /**
     * Measuring Checkout Options
     * https://developers.google.com/tag-manager/enhanced-ecommerce#checkout_option
     */
    $(document).on('change', 'input.delivery_option_radio', function () {

        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log("changed shipping method");
        }

        var optionValue = $(this).val();
        if ((temp = $(this).closest('tr')) && temp.length &&
            (temp = temp.find('td.delivery_option_logo')) && temp.length &&
            (temp = temp.next('td')) && temp.length &&
            (temp = temp.find('strong')) && temp.length) {
            optionValue = temp.text().trim();
        }

        var checkoutOption = {
            'event': 'checkoutOption',
            'ecommerce': {
                'checkoutOption': {
                    'actionField': {
                        'step': 3,
                        'option': optionValue
                    }
                }
            }
        };

        PShowConversionJS.dataLayer.push(checkoutOption);
    });

    $(document).on('click', '.payment_module a', function (e) {

        const productUrl = $(this).attr('href').trim();

        // give some time for script to push event and redirect
        setTimeout(function () {
            document.location = productUrl;
        }, 150);

        e.preventDefault();

        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log("selected payment method");
        }

        var anchor = $(this);

        var checkoutOption = {
            'event': 'checkoutOption',
            'ecommerce': {
                'checkoutOption': {
                    'actionField': {
                        'step': 4,
                        'option': anchor.attr('title').trim()
                    }
                }
            },
            'eventCallback': function () {
                // document.location = anchor.attr('href');
            }

        };

        PShowConversionJS.dataLayer.push(checkoutOption);

        return false;
    });
    /**
     * End of Measuring Checkout Options
     */

    /**
     * Measuring Checkout Steps
     * https://developers.google.com/tag-manager/enhanced-ecommerce#checkout_option
     */
    if (typeof PShowConversionJS.dataLayer.orderOpc !== 'undefined') {

        if ($('.delivery_options').length && PShowConversionJS.dataLayer.orderOpc === 0) {
            PShowConversionJS.dataLayer.orderStep = 3;
        }

        if ($('.payment_module').length && PShowConversionJS.dataLayer.orderOpc === 0) {
            PShowConversionJS.dataLayer.orderStep = 4;
        }

        if (PShowConversionJS.dataLayer.controller === 'orderconfirmation') {
            PShowConversionJS.dataLayer.orderStep = 5;
        }

        if (PShowConversionJS.dataLayer.orderOpc === 0 && PShowConversionJS.dataLayer.orderStep === null) {
            PShowConversionJS.dataLayer.orderStep = 1;
        }

        var fullData = {'event': 'checkout', 'ecommerce': {'checkout': {}}};

        if (PShowConversionJS.dataLayer.orderStep > 0) {
            if (PShowConversionJS.dataLayer.debug) {
                PShowConversionJS.dataLayer.log("order step: " + PShowConversionJS.dataLayer.orderStep);
            }

            fullData.ecommerce.checkout.actionField = {'step': PShowConversionJS.dataLayer.orderStep};
        } else {
            if (PShowConversionJS.dataLayer.debug) {
                PShowConversionJS.dataLayer.log("order opc");
            }
        }

        if ($('#cart_summary').length) {
            var products = [];

            $('#cart_summary .cart_item').each(function () {
                var productDetails = {
                    'id': parseInt($(this).attr('id').replace('product_', '')),
                    'name': $(this).find('.product-name').text().trim(),
                    'quantity': parseInt($(this).find('.cart_quantity_input').val())
                };

                var variantElement = $(this).find('.cart_ref').next('small');
                if (variantElement.length) {
                    items = variantElement.text().split(',');
                    productDetails.variant = '';
                    for (var i in items) {
                        productDetails.variant += ' ' + items[i].replace(/.*\: (.*)/, '$1');
                    }
                    productDetails.variant = productDetails.variant.trim();
                }

                products.push(productDetails);
            });

            if (products.length) {
                fullData.ecommerce.checkout.products = products;
            }

        }

        PShowConversionJS.dataLayer.push(fullData);
    }
    /**
     * End of Measuring Checkout Steps
     */

    /**
     * Measuring Purchases
     * https://developers.google.com/tag-manager/enhanced-ecommerce#purchases
     */
    if (PShowConversionJS.dataLayer.controller === 'orderconfirmation' &&
        PShowConversionJS.dataLayer.order !== null) {

        var fullData = {
            'event': 'purchase', 'ecommerce': {
                'purchase': PShowConversionJS.dataLayer.order
            }
        };
        PShowConversionJS.dataLayer.push(fullData);

        if (typeof trackingAdsConversionId !== 'undefined' && typeof trackingAdsConversionLabel !== 'undefined') {
            PShowConversionJS.dataLayer.push(
                'event',
                'conversion',
                {
                    'send_to': trackingAdsConversionId + '/' + trackingAdsConversionLabel,
                    'value': PShowConversionJS.dataLayer.order['actionField']['revenue'],
                    'currency': 'PLN',
                    'transaction_id': PShowConversionJS.dataLayer.order['actionField']['id']
                }
            );
        }
    }
    /**
     * End of Measuring Purchases
     */

};
