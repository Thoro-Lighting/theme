<?php

use PShowConversion\Controller\Admin\SendController;

require_once dirname(__FILE__) . "/../../config.php";

class PShowConversionSendController extends SendController
{

}
