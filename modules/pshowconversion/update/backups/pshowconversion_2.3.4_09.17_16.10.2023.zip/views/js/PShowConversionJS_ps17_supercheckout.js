/* global id_product, combinations, attributesCombinations */

/**
 * File from https://prestashow.pl
 *
 * DISCLAIMER
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future.
 *
 *  @authors     PrestaShow.pl <contact@prestashow.pl>
 *  @copyright   2018 PrestaShow.pl
 *  @license     https://prestashow.pl/license
 */
PShowConversionJS.dataLayer.initMeasuring = function () {

    if (!PShowConversionJS.dataLayer.active) {
        return;
    }

    /*
     * Measuring Product Impressions
     * https://developers.google.com/tag-manager/enhanced-ecommerce#product-impressions
     */

    var gtmProducts = [];
    var listNum = [];

    $('.product-miniature').each(function () {

        var listTitle = $(this).closest('.products-section-title');
        if (listTitle.length) {
            listTitle = listTitle.text().trim();
        } else {
            listTitle = 'none';
        }

        if (typeof listNum[listTitle] === 'undefined') {
            listNum[listTitle] = 1;
        } else {
            ++listNum[listTitle];
        }

        var productDetails = {
            'name': $(this).find('[itemprop="name"]').text().trim(),
            'price': $(this).find('[itemprop="price"]').text().trim()
                .replace(/([^0-9\.\,]+)/g, '').replace(',', '.'),
            'position': listNum[listTitle],
        };

        if (listTitle !== 'none') {
            productDetails.list = listTitle;
        }

        gtmProducts.push(productDetails);
    });

    if (gtmProducts.length) {
        PShowConversionJS.dataLayer.push({
            'event': 'impressions',
            'ecommerce': {'impressions': gtmProducts}
        });
    }

    /*
     * End of Measuring Product Impressions
     */

    /*
     * Measuring Views of Product Details
     * https://developers.google.com/tag-manager/enhanced-ecommerce#product-impressions
     */

    if ($('body').attr('id') === 'product') {

        var productContainer = $('#main[itemtype="https://schema.org/Product"]');

        // prepare product details
        var productDetails = {};

        // append product id
        var productId = parseInt($('body').attr('class')
            .replace(/.*product\-id\-([0-9]+).*/, '$1'));
        if (!isNaN(productId)) {
            productDetails.id = productId;

            // append product price
            if (productContainer.find('[itemprop="price"]').length) {
                productDetails.price = productContainer.find('[itemprop="price"]')
                    .attr('content').trim().replace(/([^0-9\.\,]+)/, '').replace(',', '.');
            }

            // append product category
            if ($('.breadcrumb a').length) {
                productDetails.category = $('.breadcrumb a').last()
                    .closest('li').prev('li').find('a').text().trim()
                    .toLowerCase().replace(' ', '-');
            }

            if (productContainer.find('[itemprop="name"]').length) {
                productDetails.name = productContainer.find('[itemprop="name"]').text().trim();
            }

            PShowConversionJS.dataLayer.log("displayed details of the product #" + productDetails.id);

            var fullData = {
                'event': 'detail', 'ecommerce': {'detail': {'products': [productDetails]}}
            };

            // push event
            PShowConversionJS.dataLayer.push(fullData);
        }
    }

    /*
     * End of Measuring Views of Product Details
     */

    /*
     * Measuring Product Clicks
     */

    $(document).on('click', '.product-miniature a', function (e) {

        e.preventDefault();

        var productContainer = $(this).closest('[itemtype="http://schema.org/Product"]');

        // give half second for script to push event and redirect
        var productUrl = $(this).attr('href').trim();
        setTimeout(function () {
            document.location = productUrl;
        }, 500);

        // prepare product details
        var productDetails = {
            'name': productContainer.find('[itemprop="name"]').text().trim(),
            'id': productContainer.attr('data-id-product') + '-'
                + productContainer.attr('data-id-product-attribute'),
            'price': productContainer.find('[itemprop="price"]').text().trim()
                .replace(/([^0-9\.\,]+)/g, '').replace(',', '.')
        };

        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log("clicked on product " + productDetails.name);
            PShowConversionJS.dataLayer.log(productDetails);
        }

        var fullData = {
            'event': 'productClick',
            'ecommerce': {'click': {'products': [productDetails]}},
            'eventCallback': function () {
                // redirect to the product page
                document.location = productUrl;
            }
        };

        // push event
        PShowConversionJS.dataLayer.push(fullData);

        return false;
    });

    /*
     * End of Measuring Product Clicks
     */

    /*
     * Measuring Additions to a Shopping Cart
     */

    // save current shopping cart details
    if (typeof prestashop.cart !== 'undefined' &&
        typeof prestashop.cart.products !== 'undefined') {

        PShowConversionJS.shopping_cart = prestashop.cart.products;

        prestashop.addListener('updateCart', function (data) {

            var product = null;

            if (typeof data.resp === 'undefined' ||
                typeof data.resp.success === 'undefined' ||
                !data.resp.success) {

                if (typeof data.reason !== 'undefined' &&
                    ((typeof data.reason.productId !== 'undefined' &&
                        data.reason.productId) ||
                        (typeof data.reason.id_product !== 'undefined' &&
                            data.reason.id_product))) {

                    var productId = 0;
                    if (typeof data.reason.productId !== 'undefined') {
                        productId = data.reason.productId;
                    } else {
                        productId = data.reason.id_product;
                    }

                    $.ajax({
                        dataType: 'json',
                        url: $('.js-cart').data('refresh-url').replace('refresh', 'update')
                    }).success(function (resp) {
                        prestashop.cart = resp.cart;

                        // find product with changed quantity
                        for (var x in PShowConversionJS.shopping_cart) {
                            var tempProduct1 = $.extend(true, {}, PShowConversionJS.shopping_cart[x]);

                            if (parseInt(productId) === parseInt(tempProduct1.id_product)) {

                                for (var y in prestashop.cart.products) {
                                    var tempProduct2 = $.extend(true, {}, prestashop.cart.products[y]);

                                    if (parseInt(productId) === parseInt(tempProduct2.id_product) &&
                                        parseInt(tempProduct1.id_product_attribute) === parseInt(tempProduct2.id_product_attribute) &&
                                        parseInt(tempProduct1.cart_quantity) !== parseInt(tempProduct2.cart_quantity)) {
                                        product = tempProduct2;
                                        product.cart_quantity = Math.abs(
                                            parseInt(tempProduct1.cart_quantity) - parseInt(tempProduct2.cart_quantity)
                                        );
                                        break;
                                    }
                                }
                            }

                            var fullData = {
                                'ecommerce': {
                                    'add': {
                                        'products': [{
                                            'name': product.name,
                                            'id': product.id_product,
                                            'price': product.price,
                                            'quantity': product.cart_quantity,
                                        }]
                                    }
                                }
                            };

                            if (tempProduct1.cart_quantity < product.cart_quantity) {
                                fullData.event = 'addToCart';
                            } else {
                                fullData.event = 'removeFromCart';
                            }

                            // push event
                            PShowConversionJS.dataLayer.push(fullData);
                        }
                    });
                }

                return;
            }

            // find product in the shopping cart
            for (var i in data.resp.cart.products) {
                if (parseInt(data.resp.cart.products[i].id_product) === parseInt(data.resp.id_product) &&
                    parseInt(data.resp.cart.products[i].id_product_attribute) === parseInt(data.resp.id_product_attribute)) {
                    product = data.resp.cart.products[i];
                    break;
                }
            }

            // find product in the shopping cart cache
            var productCache = null;
            for (var i in PShowConversionJS.shopping_cart) {
                if (parseInt(PShowConversionJS.shopping_cart.id_product) === parseInt(data.resp.id_product) &&
                    parseInt(PShowConversionJS.shopping_cart.id_product_attribute) === parseInt(data.resp.id_product_attribute)) {
                    productCache = data.resp.cart.products[i];
                    break;
                }
            }

            var fullData = {
                'ecommerce': {
                    'add': {
                        'products': [{
                            'name': product.name,
                            'id': product.id_product,
                            'price': product.price,
                            'quantity': product.cart_quantity,
                        }]
                    }
                }
            };
            if (productCache === null || productCache.cart_quantity < product.cart_quantity) {
                fullData.event = 'addToCart';
            } else {
                fullData.event = 'removeFromCart';
            }

            // push event
            PShowConversionJS.dataLayer.push(fullData);

        });
    }

    /*
     * End of Measuring Additions to a Shopping Cart
     */

    PShowConversionJS.sendCheckoutStep = function (checkoutStep) {
        var checkout = {
            'event': 'checkout',
            'ecommerce': {
                'checkout': {
                    'actionField': {
                        'step': checkoutStep
                    }
                }
            }
        };

        PShowConversionJS.dataLayer.push(checkout);
    };

    if ($('body').attr('id') === 'cart') {
        // checkout-step = 1
        PShowConversionJS.sendCheckoutStep(1);
    }

    if ($('body').attr('id') === 'module-supercheckout-supercheckout') {
        // checkout-step = 1
        PShowConversionJS.sendCheckoutStep(1);

        /**
         * Measuring Checkout Options
         * https://developers.google.com/tag-manager/enhanced-ecommerce#checkout_option
         */

        $(document).on('change', 'input.supercheckout_shipping_option', function () {

            if (PShowConversionJS.dataLayer.debug) {
                PShowConversionJS.dataLayer.log("changed shipping method");
            }

            var checkoutStep = 3;
            var optionValue = $('label[for="' + $(this).attr('id') + '"]').text().trim();
            var checkoutOption = {
                'event': 'checkoutOption',
                'ecommerce': {
                    'checkoutOption': {
                        'actionField': {
                            'step': checkoutStep,
                            'option': optionValue
                        }
                    }
                }
            };

            PShowConversionJS.dataLayer.push(checkoutOption);
        });

        $(document).on('change', 'input[name="payment_method"]', function () {

            if (PShowConversionJS.dataLayer.debug) {
                PShowConversionJS.dataLayer.log("selected payment method");
            }

            var checkoutStep = 4;
            var optionValue = $('label[for="' + $(this).attr('id') + '"]').text().trim();
            var checkoutOption = {
                'event': 'checkoutOption',
                'ecommerce': {
                    'checkoutOption': {
                        'actionField': {
                            'step': checkoutStep,
                            'option': optionValue
                        }
                    }
                }
            };

            PShowConversionJS.dataLayer.push(checkoutOption);
        });

        /**
         * End of Measuring Checkout Options
         */

        /**
         * Measuring Checkout Steps
         * https://developers.google.com/tag-manager/enhanced-ecommerce#checkout_option
         */

        // checkout-step = 2
        $(document).on('change', '#checkoutShippingAddress input', function () {
            PShowConversionJS.sendCheckoutStep(2);
        });

        // checkout-step = 3
        $(document).on('change', '#shipping-method input', function () {
            PShowConversionJS.sendCheckoutStep(3);
        });

        // checkout-step = 4
        $(document).on('click', '#payment-method input', function () {
            PShowConversionJS.sendCheckoutStep(4);
        });

        // checkout-step = 5
        $(document).on('submit', 'form#velsof_supercheckout_form', function () {
            PShowConversionJS.sendCheckoutStep(5);
        });

        /**
         * End of Measuring Checkout Steps
         */

    }

    /*
     * Measuring Purchases
     * https://developers.google.com/tag-manager/enhanced-ecommerce#purchases
     */

    // if (PShowConversionJS.dataLayer.controller === 'orderconfirmation' &&
    //     PShowConversionJS.dataLayer.order !== null) {
    //
    //     var fullData = {
    //         'event': 'purchase', 'ecommerce': {
    //             'purchase': PShowConversionJS.dataLayer.order
    //         }
    //     };
    //     PShowConversionJS.dataLayer.push(fullData);
    // }

    /*
     * End of Measuring Purchases
     */

};
