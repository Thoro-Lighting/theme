/* global id_product, combinations, attributesCombinations */

/**
 * File from https://prestashow.pl
 *
 * DISCLAIMER
 * Do not edit or add to this file if you wish to upgrade this module to newer
 * versions in the future.
 *
 *  @authors     PrestaShow.pl <contact@prestashow.pl>
 *  @copyright   2022 PrestaShow.pl
 *  @license     https://prestashow.pl/license
 */

window.pshowconversion = () => {
};
String.prototype.ucfirst = function () {
    return this.charAt(0).toUpperCase() + this.slice(1);
};
const PShowConversionJS = {
    'dataLayer': {},
};

PShowConversionJS.dataLayer.debug = false;
PShowConversionJS.dataLayer.intervals = [];
PShowConversionJS.dataLayer.eventNamePrefix = null;
PShowConversionJS.dataLayer.order = null;

PShowConversionJS.productDetails = [];

PShowConversionJS.dataLayer.push = function () {
    let args = arguments;
    if (arguments.length === 1 && typeof arguments[0].ecommerce !== 'undefined') {
        args = arguments[0];
    }

    if (typeof args.event !== 'undefined' && PShowConversionJS.dataLayer.eventNamePrefix) {
        args.event = PShowConversionJS.dataLayer.eventNamePrefix + args.event;
    }

    args.google_tag_params = PShowConversionJS.dataLayer.parseGoogleTagParams(args);

    // UA
    if (PShowConversionJS.dataLayer.debug) {
        PShowConversionJS.dataLayer.log(args, 'ua');
    }
    window.dataLayer.push(args);

    // GA4
    let ga4Event = PShowConversionJS.dataLayer.convertUAEventToGA4Event(JSON.parse(JSON.stringify(args)));
    if (ga4Event) {
        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log(ga4Event, 'ga4');
        }
        window.dataLayer.push(ga4Event);
    }
};

PShowConversionJS.dataLayer.ga4EventCache = {
    checkout: {},
};

PShowConversionJS.dataLayer.convertUAEventToGA4Event = (event) => {
    const convertProductList = (productList) => {
        if (typeof productList === 'undefined' || !productList) {
            return [];
        }
        return productList.map((product) => {
            return {
                item_id: product.id,
                item_name: product.name,
                item_brand: product?.brand ?? null,
                item_category: product?.category ?? null,
                item_variant: product?.variant ?? null,
                price: product?.price ?? null,
                quantity: product?.quantity ?? 1,
                currency: product?.currency ?? 'PLN',
                index: product?.position ?? null,
                item_list_name: product?.list ?? null,
                coupon: product?.coupon ?? null,
                affiliation: product?.affiliation ?? null,
            };
        });
    }
    const findEventValueAndCurrencyFromEvent = (event) => {
        // Currency of the items associated with the event, in 3-letter ISO 4217 format.
        if (!event?.currency) {
            event.currency = event?.items[0]?.currency ?? 'PLN';
        }
        // The monetary value of the event.
        event.value = event?.items.reduce((total, item) => {
            return total + (item.price * item.quantity);
        }, 0);
        return event;
    }
    if (event?.ecommerce?.products) {
        event.items = convertProductList(event.ecommerce.products);
        delete event?.ecommerce?.products;
    }
    if (event?.currencyCode) {
        event.currency = event.currencyCode;
        delete event?.currencyCode;
    }

    switch (event.event) {
        case 'productImpressions':
        case 'impressions':
            event.event = 'view_item_list';
            event.items = convertProductList(event?.ecommerce?.impressions);

            delete event?.ecommerce?.impressions;
            break;
        case 'categoryView':
            return null;
        case 'productDetailImpression':
        case 'productView':
            event.event = 'view_item';
            event.items = convertProductList(event.ecommerce.detail.products);
            event = findEventValueAndCurrencyFromEvent(event);

            delete event?.ecommerce?.detail;
            break;
        case 'addToCart':
            event.event = 'add_to_cart';
            event.items = convertProductList(event.ecommerce.add.products);
            event = findEventValueAndCurrencyFromEvent(event);

            delete event?.ecommerce?.add;
            break;
        case 'removeFromCart':
            event.event = 'remove_from_cart';
            event.items = convertProductList(event.ecommerce.remove.products);
            event = findEventValueAndCurrencyFromEvent(event);

            delete event?.ecommerce?.remove;
            break;
        case 'productClick':
            event.event = 'select_item';
            // The name of the list in which the item was presented to the user.
            event.item_list_name = event.ecommerce.click?.actionField?.list ?? 'product-list';

            event.items = convertProductList(event.ecommerce.click.products);
            event = findEventValueAndCurrencyFromEvent(event);

            delete event?.ecommerce?.click;
            break;
        case 'checkout':
            PShowConversionJS.dataLayer.ga4EventCache.checkout = event;

            switch (event.ecommerce?.checkout?.actionField?.step) {
                case 1:
                    if (PShowConversionJS.dataLayer.controller === 'cart') {
                        event.event = 'view_cart';
                    } else {
                        event.event = 'begin_checkout';
                    }
                    break;
                default:
                    return null;
            }

            event.items = convertProductList(event.ecommerce.checkout.products);
            event = findEventValueAndCurrencyFromEvent(event);

            delete event?.ecommerce?.checkout;
            break;
        case 'purchase':
            event.event = 'purchase';
            // The unique identifier of a transaction.
            event.transaction_id = event.ecommerce.purchase.actionField.id;
            // Shipping cost associated with a transaction.
            event.shipping = event.ecommerce.purchase.actionField.shipping;
            event.items = convertProductList(event.ecommerce.purchase.products);
            event = findEventValueAndCurrencyFromEvent(event);
            // The monetary value of the event.
            event.value = event.ecommerce.purchase.actionField.revenue;

            delete event?.ecommerce?.purchase;
            break;
        case 'checkoutOption':
            switch (event.ecommerce?.checkoutOption?.actionField?.step) {
                case 3:
                    event.event = 'add_shipping_info';
                    event.shipping_tier = event.ecommerce?.checkoutOption?.actionField?.option;
                    break;
                case 4:
                    event.event = 'add_payment_info';
                    event.payment_type = event.ecommerce?.checkoutOption?.actionField?.option;
                    break;
                default:
                    return null;
            }
            if (PShowConversionJS.dataLayer.ga4EventCache.checkout) {
                const checkoutEvent = PShowConversionJS.dataLayer.ga4EventCache.checkout;
                event.items = convertProductList(checkoutEvent.ecommerce.checkout.products);
                event = findEventValueAndCurrencyFromEvent(event);
            } else {
                return null;
            }

            delete event.ecommerce?.checkoutOption;
            break;
        default:
            PShowConversionJS.dataLayer.warn(`Unknown event: ${event.event}`, 'ga4');
            break;
    }

    if (event?.ecommerce) {
        delete event?.ecommerce;
    }

    return event;
}

PShowConversionJS.dataLayer.parseGoogleTagParams = (args) => {
    let google_tag_params = {
        /**
         * na listingach produktów (wszystkie produkty dostępne na listingu),
         * na karcie produktu (wyświetlany produkt),
         * na stronie koszyka (wszystkie produkty w koszyku)
         */
        // ecomm_prodid: '', // products id
        /**
         * na listingach suma cen wyświetlanych produktów produktów (wszystkie produkty dostępne na listingu),
         * na karcie cena produktu (wyświetlany produkt),
         * na stronie koszyka (suma kosztu wszystkich produktów dodanych do koszyka
         */
        // ecomm_totalvalue: '', // total page value
        /**
         * kategorie: ‘category’,
         * wyniki wyszukiwania: ‘search’,
         * strona główna: ‘index’,
         * karta produktu: ‘product’,
         * strona koszyka: ‘cart’
         */
        // ecomm_pagetype: $('body').attr('id'), // page type
        /**
         * na listingach produktów (wszystkie produkty dostępne na listingu),
         * na karcie produktu (wyświetlany produkt),
         * na stronie koszyka (wszystkie produkty w koszyku)
         */
        // ecomm_pagename: '', // page name
        /**
         * na listingach produktów (wszystkie produkty dostępne na listingu),
         * na karcie produktu (wyświetlany produkt),
         * na stronie koszyka (wszystkie produkty w koszyku)
         */
        // ecomm_brand: '', // product brand
        /**
         * na listingach produktów (wszystkie produkty dostępne na listingu),
         * na karcie produktu (wyświetlany produkt),
         * na stronie koszyka (wszystkie produkty w koszyku)
         */
        // ecomm_category: '', // product category
        /**
         * na listingach produktów (wszystkie produkty dostępne na listingu),
         * na karcie produktu (wyświetlany produkt),
         * na stronie koszyka (wszystkie produkty w koszyku)
         */
        // ecomm_model: '', // product model
        /**
         * przesyłane wraz z eventem purchase
         */
        // ecomm_quantity: '', // num of ordered products
    };

    let productsId = [];
    let productsName = [];
    let productsBrand = [];
    let productsCategory = [];
    let productsVariant = [];
    let totalProductsPrice = 0.0;
    let totalProductsQuantity = 0;

    const pushProductDetails = (product) => {
        productsId.push(product.id);
        totalProductsPrice += parseFloat(product.price);
        productsName.push(product.name?.replace(',', ' '));
        productsBrand.push(product.brand?.replace(',', ' '));
        productsCategory.push(product.category?.replace(',', ' '));
        productsVariant.push(product.variant?.replace(',', ' '));
        totalProductsQuantity += parseInt(product.quantity);
    };

    const parseProducts = (products) => {
        for (let i in products) {
            pushProductDetails(products[i]);
        }
    };

    switch (args.event) {
        case 'categoryView':
        case 'productImpressions':
            parseProducts(args.ecommerce?.impressions || []);
            break;
        case 'productView':
        case 'productDetailImpression':
            parseProducts(args.ecommerce?.detail?.products || []);
            break;
        case 'checkout':
        case 'checkoutOption':
            parseProducts(args.ecommerce?.checkout?.products || []);
            break;
        case 'purchase':
            parseProducts(args.ecommerce?.purchase?.products || []);
            break;
        default:
            return [];
    }

    if (productsId.length) {
        google_tag_params.ecomm_prodid = productsId.join(',');
    }
    if (totalProductsPrice) {
        google_tag_params.ecomm_totalvalue = totalProductsPrice;
    }
    if (productsName.length) {
        google_tag_params.ecomm_pagename = productsName.join(',');
    }
    if (productsBrand.length) {
        google_tag_params.ecomm_brand = productsBrand.join(',');
    }
    if (productsCategory.length) {
        google_tag_params.ecomm_category = productsCategory.join(',');
    }
    if (productsVariant.length) {
        google_tag_params.ecomm_model = productsVariant.join(',');
    }
    if (totalProductsQuantity) {
        google_tag_params.ecomm_quantity = totalProductsQuantity;
    }

    return google_tag_params;
};

PShowConversionJS.dataLayer.log = (msg, target = '') => {
    if (PShowConversionJS.dataLayer.debug) {
        console.info(
            ">> PShowConversionJS.dataLayer: ",
            target ? `${target.toUpperCase()} <=` : '',
            msg
        );
    }
};

PShowConversionJS.dataLayer.error = (msg, target = '') => {
    if (PShowConversionJS.dataLayer.debug) {
        console.error(
            "!! PShowConversionJS.dataLayer: ",
            target ? `${target.toUpperCase()} <=` : '',
            msg
        );
    }
};

PShowConversionJS.dataLayer.warn = (msg, target = '') => {
    if (PShowConversionJS.dataLayer.debug) {
        console.warn(
            ">! PShowConversionJS.dataLayer: ",
            target ? `${target.toUpperCase()} <=` : '',
            msg);
    }
};

PShowConversionJS.getProductDetails = (productAndVariantIds, callback) => {
    if (!productAndVariantIds.length) {
        if (callback) {
            callback(null);
        }
        return;
    }

    // filter ids which are stored in cache
    let productAndVariantIdsMissingInCache = productAndVariantIds;
    for (let i in productAndVariantIdsMissingInCache) {
        let ids = productAndVariantIdsMissingInCache[i];
        if (typeof ids === 'object') {
            if (ids.length == 2 && parseInt(ids[1]) === 0) {
                ids = ids[0];
            } else {
                ids = ids.join('-');
            }
        }

        if (typeof PShowConversionJS.productDetails[ids] !== 'undefined') {
            productAndVariantIdsMissingInCache = productAndVariantIdsMissingInCache
                .filter(function (val) {
                    return val !== productAndVariantIdsMissingInCache[i];
                });
        }
    }

    if (!productAndVariantIdsMissingInCache.length) {
        if (callback) {
            let productDetails = PShowConversionJS.getProductDetailsFromCache(productAndVariantIds);
            callback(productDetails);
        }
        return;
    }

    if (PShowConversionJS.dataLayer.debug) {
        PShowConversionJS.dataLayer.log(
            ["not found in cache: ", productAndVariantIdsMissingInCache]
        );
    }

    $.ajax({
        method: 'get',
        url: '/modules/pshowconversion/getProductDetails.php?id='
            + JSON.stringify(productAndVariantIdsMissingInCache),
        success: function (response) {
            let productDetails = JSON.parse(response);
            for (let productId in productDetails) {
                if (productDetails[productId]) {
                    if (PShowConversionJS.dataLayer.debug) {
                        PShowConversionJS.dataLayer.log(
                            ["add product #" + productId + " details to cache ", productDetails[productId]]
                        );
                    }
                    PShowConversionJS.productDetails[productId] = productDetails[productId];
                }
            }
            if (callback) {
                productDetails = PShowConversionJS.getProductDetailsFromCache(productAndVariantIds);
                callback(productDetails);
            }
        }
    });
};

PShowConversionJS.getProductDetailsFromCache = (productAndVariantIds) => {
    const result = [];
    for (let i in productAndVariantIds) {
        let ids = productAndVariantIds[i];
        if (typeof ids === 'object') {
            if (ids.length == 2 && parseInt(ids[1]) === 0) {
                ids = ids[0];
            } else {
                ids = ids.join('-');
            }
        }
        if (PShowConversionJS.dataLayer.debug) {
            PShowConversionJS.dataLayer.log(
                ["get product #" + ids + " details from cache ", PShowConversionJS.productDetails[ids]]
            );
        }
        result[ids] = PShowConversionJS.productDetails[ids];
    }
    return result;
}

PShowConversionJS.getCurrencyIsoCode = () => {
    return (typeof prestashop !== 'undefined' && typeof prestashop.currency !== 'undefined' &&
        typeof prestashop.currency.iso_code !== 'undefined') ? prestashop.currency.iso_code : null;
};

PShowConversionJS.prepareProductMiniatureDetails = () => {
    const productIdsToPrepare = [];

    $('.product-miniature').each(function () {
        const productContainer = $(this).closest('.product-miniature');
        const productId = productContainer.attr('data-id-product');
        if (typeof PShowConversionJS.productDetails[productId] !== 'undefined') {
            return;
        }

        let variantId = 0;
        if (productContainer.attr('data-id-product-attribute').length) {
            variantId = productContainer.attr('data-id-product-attribute');
        }

        productIdsToPrepare.push([productId, variantId]);
    });

    PShowConversionJS.getProductDetails(productIdsToPrepare);
};

PShowConversionJS.cookie = {
    set: (name, value, days) => {
        let expires = "";
        if (days) {
            let date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + (value || "") + expires + "; path=/";
    },

    get: (name) => {
        let nameEQ = name + "=";
        let ca = document.cookie.split(';');
        for (let i = 0; i < ca.length; i++) {
            let c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    },
};
