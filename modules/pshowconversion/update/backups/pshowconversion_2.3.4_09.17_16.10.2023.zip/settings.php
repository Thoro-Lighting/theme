<?php

return array(
    array(
        'type' => 'switch',
        'name' => 'experimental_gtag_campaign',
        'label' => 'Experimental: Send campaign information ( determined by the module) using gtag',
        'desc' => 'Experimental function, use carefully and verify the correct operation of the module.',
        'is_bool' => true,
        'values' => array(
            array(
                'id' => 'experimental_gtag_campaign_off',
                'value' => 1,
                'label' => 'Enabled'
            ),
            array(
                'id' => 'experimental_gtag_campaign_on',
                'value' => 0,
                'label' => 'Disabled'
            ),
        ),
        'default' => false,
    ),

);
