<?php

require_once dirname(__FILE__) . "/../../config.php";

use PShowConversion\Controller\Admin\MainController;

class PShowConversionMainController extends MainController
{
}
