<?php

global $_MODULE;


// *****
// /src/Controller/Admin/SendController.php
// ***

$_MODULE['<{pshowconversion}prestashop>pshowconversionsendcontroller_1d44fd5ebda4752f2a93b5c5a6bb5ae3']
	//'Send Controller'
	= 'Wyślij kontroler';

$_MODULE['<{pshowconversion}prestashop>pshowconversionsendcontroller_2d624dec9fc025d4aefd858fe498dcba']
	//'Send transactions'
	= 'Wyślij transakcje';


// *****
// /src/Controller/Admin/MainController.php
// ***

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_4c95b8d9029207d189a32b19c91b9827']
	//'Main Controller'
	= 'Główny kontroler';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_0646cf3b3fbe76d12496ead66127cac2']
	//'Uninstall module "Google Analytics" to prevent discrepancies in statistics.')); } if (Module::isInstalled('plpganalytics'
	= 'Odinstaluj moduł "Google Analytics", aby zapobiec rozbieżnościom w statystykach."); } if (Module::isInstalled(\'plpganalytics';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_43a2affc5cb786c26c91601e7ec0a19f']
	//'Uninstall module "plpganalytics" to prevent discrepancies in statistics.'
	= 'Odinstaluj moduł "plpganalytics", aby zapobiec rozbieżnościom w statystykach.';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_e6a355dac1d2c7d892e6436f0b40f6b0']
	//'Setting up this module is not just about filling out all the forms. Before starting the configuration, you should carefully read %s official documentation from Google %s or get help from some advertising agency for example.'
	= 'Konfiguracja tego modułu to nie tylko wypełnienie wszystkich formularzy. Przed rozpoczęciem konfiguracji powinieneś uważnie przeczytać %s oficjalną dokumentację od Google %s lub uzyskać pomoc na przykład od agencji reklamowej.';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_a68f229977e11398239df7427066e3d5']
	//'Override removed'
	= 'Nadpisanie usunięte';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_a12c56490da55dd263e4bbc9867d44ff']
	//'Override installed'
	= 'Nadpisanie zainstalowane';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_7af564b419a228b549c7c379d47866ab']
	//'Unfortunately, we failed to install new overrides.'
	= 'Niestety, nie udało nam się zainstalować nowych nadpisań.';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_9010eb277aa60c8a449e61d148f6397e']
	//'If you need help, write to us and send the FTP access data.'
	= 'Jeśli potrzebujesz pomocy, napisz do nas i wyślij dane dostępu do FTP.';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_978bfeb38b43785cc4fa2e94bb16db1c']
	//'Reinstall overrides'
	= 'Ponownie zainstaluj nadpisania';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_b95d3d403307efa40962df363734e941']
	//'Module Settings'
	= 'Ustawienia modułu';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_c888438d14855d7d96a2724ee9c306bd']
	//'Settings updated'
	= 'Ustawienia zostały zaktualizowane';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_dc1526f7098ae4f9778d93d5942d9b37']
	//'Module Settings'); if (Tools::isSubmit('submitSave'
	= 'Ustawienia modułu"); if (Tools::isSubmit(\'submitSave';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_c888438d14855d7d96a2724ee9c306bd']
	//'Settings updated'
	= 'Ustawienia zostały zaktualizowane';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_8bb6f7d8312f49d4cca915e9f255d595']
	//'Module Settings'); if (Tools::isSubmit('submitSave')) { Configuration::updateValue('pshowconversion_optimizeid', pSQL(Tools::getValue('optimizeId'
	= 'Module Settings\'); if (Tools::isSubmit(\'submitSave\')) { Configuration::updateValue(\'pshowconversion_optimizeid\', pSQL(Tools::getValue(\'optimizeId';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_c888438d14855d7d96a2724ee9c306bd']
	//'Settings updated'
	= 'Ustawienia zostały zaktualizowane';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_58eb62bd8b60337971cdd4a25de5cc5c']
	//'Module Settings'); if (Tools::isSubmit('submitSave')) { Configuration::updateValue( 'pshowconversion_trackingAdsConversionId', pSQL(Tools::getValue('trackingAdsConversionId')) ); Configuration::updateValue( 'pshowconversion_trackingAdsConversionLabel', pSQL(Tools::getValue('trackingAdsConversionLabel'
	= 'Module Settings\'); if (Tools::isSubmit(\'submitSave\')) { Configuration::updateValue( \'pshowconversion_trackingAdsConversionId\', pSQL(Tools::getValue(\'trackingAdsConversionId\'))); Configuration::updateValue( \'pshowconversion_trackingAdsConversionLabel\', pSQL(Tools::getValue(\'trackingAdsConversionLabel\')))))))))).';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_c888438d14855d7d96a2724ee9c306bd']
	//'Settings updated'
	= 'Ustawienia zostały zaktualizowane';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_eac5dc97bf50c9e82aa02e792dbdf621']
	//'Module Settings'); if (Tools::isSubmit('submitSave')) { Configuration::updateValue('pshowconversion_tagmanagerid', pSQL(Tools::getValue('tagManagerId'
	= 'Module Settings\'); if (Tools::isSubmit(\'submitSave\')) { Configuration::updateValue(\'pshowconversion_tagmanagerid\', pSQL(Tools::getValue(\'tagManagerId';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_c888438d14855d7d96a2724ee9c306bd']
	//'Settings updated'
	= 'Ustawienia zostały zaktualizowane';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_1c898fc54cdb574896fcce35a010fc1a']
	//'DataLayer Settings'); if (Tools::isSubmit('submitSave')) { Configuration::updateValue('pshowconversion_dataLayerEnabled', (int)Tools::getValue('dataLayerEnabled')); Configuration::updateValue('pshowconversion_dataLayerDebug', (int)Tools::getValue('dataLayerDebug'
	= 'DataLayer Settings\'); if (Tools::isSubmit(\'submitSave\')) { Configuration::updateValue(\'pshowconversion_dataLayerEnabled\', (int)Tools::getValue(\'dataLayerEnabled\')); Configuration::updateValue(\'pshowconversion_dataLayerDebug\', (int)Tools::getValue(\'dataLayerDebug';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_c888438d14855d7d96a2724ee9c306bd']
	//'Settings updated'
	= 'Ustawienia zostały zaktualizowane';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_ce0be71e33226e4c1db2bcea5959f16b']
	//'Log'
	= 'Dziennik';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_bcfb088eab1eccd63adc1b1e483585bc']
	//'OAuth'); if (Tools::isSubmit('submitSave'
	= 'OAuth\'); if (Tools::isSubmit(\'submitSave';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_c888438d14855d7d96a2724ee9c306bd']
	//'Settings updated'
	= 'Ustawienia zostały zaktualizowane';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_6d8c9f1d5a324f0955f8bbee1d1b753c']
	//'Track user activity and send e-commerce events to GA4:'
	= 'Śledź aktywność użytkowników i wysyłaj zdarzenia e-commerce do GA4:';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_93cba07454f06a4a960172bbd6e2a435']
	//'Yes'
	= 'Tak';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_bafd7322c6e97d25b6299b5d6fe8920b']
	//'No'
	= 'Nie';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_47592d022bb8d29662cde0d4e79db74a']
	//'missing GA4 ID') . ', ' : ''
	= 'brakujący identyfikator GA4") . \', \' : \'';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_3575ad124ac25aaf1d3dae8033ed499a']
	//'Google Tag disabled') : '') . '
	= 'Google Tag disabled\') : \'\') . ';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_a9355d1476bccd74695d4c3f3e471160']
	//'Send e-commerce events to GTM:'
	= 'Wysyłaj zdarzenia e-commerce do GTM:';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_93cba07454f06a4a960172bbd6e2a435']
	//'Yes'
	= 'Tak';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_bafd7322c6e97d25b6299b5d6fe8920b']
	//'No'
	= 'Nie';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_9400bfc12ee73cd4042dd0dc5de297a3']
	//'missing GTM id') . '
	= 'brakujący identyfikator GTM") . ';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_d03ef4d10405b5f02aecb908f3655432']
	//'Send transactions via Measurement Protocol to GA4:'
	= 'Wysyłaj transakcje za pośrednictwem protokołu pomiarowego do GA4:';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_93cba07454f06a4a960172bbd6e2a435']
	//'Yes'
	= 'Tak';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_bafd7322c6e97d25b6299b5d6fe8920b']
	//'No'
	= 'Nie';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_47592d022bb8d29662cde0d4e79db74a']
	//'missing GA4 ID') . ', ' : ''
	= 'brakujący identyfikator GA4") . \', \' : \'';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_c2e397d8469b35218f23ee1d1bd80685']
	//'missing MP secret key') . ', ' : ''
	= 'brakujący klucz tajny MP") . \', \' : \'';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_958c0324521eed37750a9cbe29f862f7']
	//'Measurement Protocol disabled') . ', ' : ''
	= 'Measurement Protocol disabled") . \', \' : \'';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_004469399cca2cb52aab2ad23f0d5fe2']
	//'CRON task has not been started today') : '' ) . '
	= 'Zadanie CRON nie zostało uruchomione dzisiaj\') : \'\' ) . ';

$_MODULE['<{pshowconversion}prestashop>pshowconversionmaincontroller_7803b09318d05383a53d7ff6b1fbc548']
	//'According to the current configuration of the module:'
	= 'Zgodnie z bieżącą konfiguracją modułu:';


// *****
// /src/Module.php
// ***

$_MODULE['<{pshowconversion}prestashop>module_1fffa62537fc7eee3f3c4227dc57fee5']
	//'PShow Conversion'
	= 'Konwersja PShow';

$_MODULE['<{pshowconversion}prestashop>module_0a253a10c0f337c264aff1e235b5e816']
	//'Google Analytics plugin'); if (Tools::getValue('controller') == 'AdminLogin'
	= 'Google Analytics plugin\'); if (Tools::getValue(\'controller\') == \'AdminLogin';

$_MODULE['<{pshowconversion}prestashop>module_5528715d76a72d97de76212d9432c29d']
	//'The order has been sent to the Google Analytics'
	= 'Zamówienie zostało wysłane do Google Analytics';

$_MODULE['<{pshowconversion}prestashop>module_7e911168254fc44184889dc5868279f2']
	//'The order has not been sent to the Google Analytics'
	= 'Zamówienie nie zostało wysłane do Google Analytics';

$_MODULE['<{pshowconversion}prestashop>module_2408b764a20696523d1a7e9cf0397d31']
	//'This source will be used while sending transaction to Google Analytics.'
	= 'To źródło będzie używane podczas wysyłania transakcji do Google Analytics.';

$_MODULE['<{pshowconversion}prestashop>module_44749712dbec183e983dcd78a7736c41']
	//'Date'
	= 'Data';

$_MODULE['<{pshowconversion}prestashop>module_f31bbdd1b3e85bccd652680e16935819']
	//'Source'
	= 'Źródło';

$_MODULE['<{pshowconversion}prestashop>module_c41a31890959544c6523af684561abe5']
	//'Target'
	= 'Cel';

$_MODULE['<{pshowconversion}prestashop>module_6a55cfe04e30b9fcb7de466de70798b5']
	//'Best source'
	= 'Najlepsze źródło';

$_MODULE['<{pshowconversion}prestashop>module_2408b764a20696523d1a7e9cf0397d31']
	//'This source will be used while sending transaction to Google Analytics.'
	= 'To źródło będzie używane podczas wysyłania transakcji do Google Analytics.';

$_MODULE['<{pshowconversion}prestashop>module_745983303dba472a056af0cfde65a86a']
	//'Order sent to Google Analytics.'
	= 'Zamówienie wysłane do Google Analytics.';

$_MODULE['<{pshowconversion}prestashop>module_8e46f6ecf73c49b1c8962c6dcaa98835']
	//'See details'
	= 'Zobacz szczegóły';

$_MODULE['<{pshowconversion}prestashop>module_2ef2853b8b92573adfcf053ac0f01003']
	//'Order not sent to Google Analytics.'
	= 'Zamówienie nie jest wysyłane do Google Analytics.';

$_MODULE['<{pshowconversion}prestashop>module_c04f34cb709cc96c71200d701053d85b']
	//'Change settings when the order should be sent.'
	= 'Zmień ustawienia, kiedy zamówienie ma zostać wysłane.';

$_MODULE['<{pshowconversion}prestashop>module_fb61758d0f0fda4ba867c3d5a46c16a7']
	//'Sources'
	= 'Źródła';

$_MODULE['<{pshowconversion}prestashop>module_44749712dbec183e983dcd78a7736c41']
	//'Date'
	= 'Data';

$_MODULE['<{pshowconversion}prestashop>module_f31bbdd1b3e85bccd652680e16935819']
	//'Source'
	= 'Źródło';

$_MODULE['<{pshowconversion}prestashop>module_c41a31890959544c6523af684561abe5']
	//'Target'
	= 'Cel';

$_MODULE['<{pshowconversion}prestashop>module_6a55cfe04e30b9fcb7de466de70798b5']
	//'Best source'
	= 'Najlepsze źródło';

$_MODULE['<{pshowconversion}prestashop>module_5ea637bf8177b07ce3f8a61ed654299f']
	//'Sources not found. Possible reasons:'
	= 'Nie znaleziono źródeł. Możliwe przyczyny:';

$_MODULE['<{pshowconversion}prestashop>module_ebd5cedab4adaadbf2ea38c0786f96b9']
	//'- customer entered the store by typing the address manually'
	= '- klient wszedł do sklepu, wpisując adres ręcznie';

$_MODULE['<{pshowconversion}prestashop>module_b5538353b8abf81d4ef4a856dd9eb81f']
	//'- customer entered the store by pasting the address from the clipboard'
	= '- klient wszedł do sklepu wklejając adres ze schowka';

$_MODULE['<{pshowconversion}prestashop>module_67c934d377789b07b1e379152101fc2a']
	//'- customer opened anchor in new browser window or tab'
	= '- Klient otworzył kotwicę w nowym oknie lub zakładce przeglądarki';


// *****
// /views/templates/side_menu.tpl
// ***

$_MODULE['<{pshowconversion}prestashop>side_menu_1778e0e8555dc044231c1d615b41ddea']
	//'MultiStore'
	= 'MultiStore';

$_MODULE['<{pshowconversion}prestashop>side_menu_d86cf69a8b82547a94ca3f6a307cf9a6']
	//'Google Analytics'
	= 'Google Analytics';

$_MODULE['<{pshowconversion}prestashop>side_menu_1d3c65b2b03ef35e14df6b163ea3a1f6']
	//'Google Tag Manager'
	= 'Menedżer tagów Google';

$_MODULE['<{pshowconversion}prestashop>side_menu_7b1efe11eee5a189c475cc7235272284']
	//'DataLayer'
	= 'DataLayer';

$_MODULE['<{pshowconversion}prestashop>side_menu_031a0cece38c4739df67f910dcabf1bd']
	//'Google Optimize'
	= 'Google Optimize';

$_MODULE['<{pshowconversion}prestashop>side_menu_d323dff6f7de41c0b9af4c35e21dc032']
	//'Google Ads'
	= 'Reklamy Google';

$_MODULE['<{pshowconversion}prestashop>side_menu_6eeda24e478154ce376f5ea50860d592']
	//'Reporting API - OAuth'
	= 'API raportowania - OAuth';

$_MODULE['<{pshowconversion}prestashop>side_menu_a8abb9b0dd7f5b6f224b210a9605cccf']
	//'Manual send transactions'
	= 'Ręczne wysyłanie transakcji';

$_MODULE['<{pshowconversion}prestashop>side_menu_7fe1bf192fbc1906e6f55e8b7114895b']
	//'See log'
	= 'Zobacz dziennik';

$_MODULE['<{pshowconversion}prestashop>side_menu_e1ba155a9f2e8c3be94020eef32a0301']
	//'Manual'
	= 'Podręcznik';


// *****
// /views/templates/admin/main_tagmanager.tpl
// ***

$_MODULE['<{pshowconversion}prestashop>main_tagmanager_1a11db3d2781e8ee1401eab17b296b6a']
	//'Module settings'
	= 'Ustawienia modułu';

$_MODULE['<{pshowconversion}prestashop>main_tagmanager_28d5c0f46f810d8cf0a57e482f6ca730']
	//'Enter Google Tag Manager ID'
	= 'Wprowadź identyfikator Menedżera tagów Google';

$_MODULE['<{pshowconversion}prestashop>main_tagmanager_1d3c65b2b03ef35e14df6b163ea3a1f6']
	//'Google Tag Manager'
	= 'Menedżer tagów Google';

$_MODULE['<{pshowconversion}prestashop>main_tagmanager_c9cc8cce247e49bae79f15173ce97354']
	//'Save'
	= 'Oszczędzaj';


// *****
// /views/templates/admin/main_reinstallOverrides.tpl
// ***

$_MODULE['<{pshowconversion}prestashop>main_reinstalloverrides_2444d1c1237bfc81a4d6310216a46eff']
	//'Here you can reinstall module overrides'
	= 'Tutaj możesz ponownie zainstalować nadpisania modułów';

$_MODULE['<{pshowconversion}prestashop>main_reinstalloverrides_6f6c77f3d31526b049eea7f47f13cdcc']
	//'Overrides are files that contain code that changes the basic operation of the store.'
	= 'Nadpisania to pliki zawierające kod, który zmienia podstawowe działanie sklepu.';

$_MODULE['<{pshowconversion}prestashop>main_reinstalloverrides_5970b718dc4217238c7e019e99670dc9']
	//'Proceed with caution, the changes are irreversible.'
	= 'Postępuj ostrożnie, zmiany są nieodwracalne.';

$_MODULE['<{pshowconversion}prestashop>main_reinstalloverrides_a6122a65eaa676f700ae68d393054a37']
	//'Start'
	= 'Rozpocznij';


// *****
// /views/templates/admin/main_index.tpl
// ***

$_MODULE['<{pshowconversion}prestashop>main_index_969ac94be8fa7fb734b2ae62b6a8d77d']
	//'You can configure Universal Analytics or Google Analytics 4 or both.'
	= 'Możesz skonfigurować Universal Analytics lub Google Analytics 4 lub oba.';

$_MODULE['<{pshowconversion}prestashop>main_index_f4b9ee7a846c9ce272c4c5b9c7180fca']
	//'Enter tracking id'
	= 'Wprowadź identyfikator śledzenia';

$_MODULE['<{pshowconversion}prestashop>main_index_81f7f91d342e96fc27db61fcc7a86ee1']
	//'To get tracking id go to:'
	= 'Aby uzyskać identyfikator śledzenia, przejdź do:';

$_MODULE['<{pshowconversion}prestashop>main_index_44a9af390e1820629ee38a27fb1233b0']
	//'Google Analytics administration'
	= 'Administracja Google Analytics';

$_MODULE['<{pshowconversion}prestashop>main_index_0e8954c176dc80a2ea9bf535d7c66815']
	//'Enter Measurement ID'
	= 'Wprowadź ID pomiaru';

$_MODULE['<{pshowconversion}prestashop>main_index_abb7f7ade5a081361bbdd3559e8b7b0d']
	//'Found in the Google Analytics UI under:'
	= 'Znajdź w interfejsie użytkownika Google Analytics w sekcji:';

$_MODULE['<{pshowconversion}prestashop>main_index_422b8998945227facb6b0080a45e0049']
	//'Read about the Google tag'
	= 'Przeczytaj o tagu Google';

$_MODULE['<{pshowconversion}prestashop>main_index_33c8996f09e572574c1027f357848385']
	//'Click to see instructions how to check if there is another tracking code in the store'
	= 'Kliknij, aby zobaczyć instrukcje, jak sprawdzić, czy w sklepie znajduje się inny kod śledzenia.';

$_MODULE['<{pshowconversion}prestashop>main_index_5ae907529df7af46c12e2731f7f88818']
	//'1. Install the Google Chrome browser extension:'
	= '1. Zainstaluj rozszerzenie przeglądarki Google Chrome:';

$_MODULE['<{pshowconversion}prestashop>main_index_664df119aa1329966b494b2389fc7ab9']
	//'2. Go to the address of your store in your browser.'
	= '2. Przejdź do adresu swojego sklepu w przeglądarce.';

$_MODULE['<{pshowconversion}prestashop>main_index_f2eca076027732e609c6bfe05e13cff7']
	//'3. In the installed extension, press the \'Enable\' button.'
	= '3. W zainstalowanym rozszerzeniu naciśnij przycisk "Włącz".';

$_MODULE['<{pshowconversion}prestashop>main_index_9d8cc0c19f84ff9925609fa9f9214b7f']
	//'4. Refresh the website.'
	= '4. Odśwież stronę internetową.';

$_MODULE['<{pshowconversion}prestashop>main_index_7d4d743aab4e9ef6dddf36810b60a539']
	//'5. The extension should not show any code labeled \'Google Analytics\' because this module do not use JavaScript tracking.'
	= '5. Rozszerzenie nie powinno wyświetlać żadnego kodu oznaczonego jako "Google Analytics", ponieważ ten moduł nie używa śledzenia JavaScript.';

$_MODULE['<{pshowconversion}prestashop>main_index_8b4b6402c44772ab63f4d7930d8270f0']
	//'Activate Google Tag?'
	= 'Aktywować Google Tag?';

$_MODULE['<{pshowconversion}prestashop>main_index_93cba07454f06a4a960172bbd6e2a435']
	//'Yes'
	= 'Tak';

$_MODULE['<{pshowconversion}prestashop>main_index_bafd7322c6e97d25b6299b5d6fe8920b']
	//'No'
	= 'Nie';

$_MODULE['<{pshowconversion}prestashop>main_index_ba248fdf0e0cdd069ded437f9d99e1a1']
	//'Module will add official Google Tag code to track user activity in the shop.'
	= 'Moduł doda oficjalny kod Google Tag do śledzenia aktywności użytkowników w sklepie.';

$_MODULE['<{pshowconversion}prestashop>main_index_038d6fa0adc30cb0223e93b87929d793']
	//'We recommend leaving this option active and removing all other tracking codes from the store. Among other things, this will allow the module to better associate the data sent from the browser (clicks and other events) with those sent from the server (transactions, sources and others).'
	= 'Zalecamy pozostawienie tej opcji aktywnej i usunięcie wszystkich innych kodów śledzenia ze sklepu. Pozwoli to między innymi modułowi lepiej powiązać dane wysyłane z przeglądarki (kliknięcia i inne zdarzenia) z danymi wysyłanymi z serwera (transakcje, źródła i inne).';

$_MODULE['<{pshowconversion}prestashop>main_index_7f77e3d7178f0b1979d13c101a456450']
	//'Enable debug mode'
	= 'Włącz tryb debugowania';

$_MODULE['<{pshowconversion}prestashop>main_index_93cba07454f06a4a960172bbd6e2a435']
	//'Yes'
	= 'Tak';

$_MODULE['<{pshowconversion}prestashop>main_index_bafd7322c6e97d25b6299b5d6fe8920b']
	//'No'
	= 'Nie';

$_MODULE['<{pshowconversion}prestashop>main_index_677441ceebb8de39d27983283aa00b69']
	//'Monitor events from your website or mobile app as Analytics collects them.'
	= 'Monitoruj zdarzenia ze swojej witryny lub aplikacji mobilnej w miarę ich zbierania przez Analytics.';

$_MODULE['<{pshowconversion}prestashop>main_index_43340e6cc4e88197d57f8d6d5ea50a46']
	//'Read more'
	= 'Czytaj więcej';

$_MODULE['<{pshowconversion}prestashop>main_index_851039c39239238440784d96ff32ae92']
	//'The module tries to find the source from which the customer got to the store (from an ad, from another site, typed the address of the store in the browser, etc.) and saves this information for later uploading to your Google services.'
	= 'Moduł próbuje znaleźć źródło, z którego klient trafił do sklepu (z reklamy, z innej strony, wpisał adres sklepu w przeglądarce itp.) i zapisuje te informacje w celu późniejszego przesłania do Twoich usług Google.';

$_MODULE['<{pshowconversion}prestashop>main_index_76d558d60cee8944e5eeb888463f178b']
	//'Ignored sources'
	= 'Ignorowane źródła';

$_MODULE['<{pshowconversion}prestashop>main_index_896493a9e47ad97adae6eef09316db18']
	//'Enter domains (or fragments of domains) which should be ignored.'
	= 'Wprowadź domeny (lub ich fragmenty), które powinny być ignorowane.';

$_MODULE['<{pshowconversion}prestashop>main_index_3c588242e2a1e1757829f8989a270312']
	//'You can enter a few domains, one per line.'
	= 'Możesz wprowadzić kilka domen, po jednej w każdym wierszu.';

$_MODULE['<{pshowconversion}prestashop>main_index_eb078e0647202953d649b0b43d04e552']
	//'Sources ignored by default:'
	= 'Źródła domyślnie ignorowane:';

$_MODULE['<{pshowconversion}prestashop>main_index_d1565c16004413aba9a49344b212f43a']
	//'Which source should be sent to Google?'
	= 'Które źródło powinno zostać wysłane do Google?';

$_MODULE['<{pshowconversion}prestashop>main_index_380ff4accdea75b8684f746674c5bf93']
	//'First source - if the customer entered from Google and then Bing, the module will send Google'
	= 'Pierwsze źródło - jeśli klient wszedł z Google, a następnie Bing, moduł wyśle Google';

$_MODULE['<{pshowconversion}prestashop>main_index_3051fc9eb0b60523332781d0817d3832']
	//'Last source - if the customer entered from Google and then Bing, the module will send Bing'
	= 'Ostatnie źródło - jeśli klient wszedł z Google, a następnie Bing, moduł wyśle Bing';

$_MODULE['<{pshowconversion}prestashop>main_index_1cc68af0f344bd199e0768f3bb4c15e5']
	//'Read about the Measurement Protocol'
	= 'Przeczytaj o protokole pomiarowym';

$_MODULE['<{pshowconversion}prestashop>main_index_95ff625307138f47329935f4716088db']
	//'Configure options below if you want to send trasactions to UA and GA4 using Measurement Protocol.'
	= 'Skonfiguruj poniższe opcje, jeśli chcesz wysyłać transakcje do UA i GA4 przy użyciu protokołu Measurement Protocol.';

$_MODULE['<{pshowconversion}prestashop>main_index_43340e6cc4e88197d57f8d6d5ea50a46']
	//'Read more'
	= 'Czytaj więcej';

$_MODULE['<{pshowconversion}prestashop>main_index_a2145e7a5daf06050418620a2aeab512']
	//'If you are passing transactions from GTM to GA, using Measurement Protocol in addition can lead to duplicate orders. Test and choose the solution that works best for you.'
	= 'Jeśli przekazujesz transakcje z GTM do GA, dodatkowe użycie Measurement Protocol może prowadzić do duplikowania zamówień. Przetestuj i wybierz rozwiązanie, które będzie dla Ciebie najlepsze.';

$_MODULE['<{pshowconversion}prestashop>main_index_f9c7290628ce601ec184a4bd3a7c2e8c']
	//'Activate Measurement Protocol'
	= 'Aktywuj protokół pomiaru';

$_MODULE['<{pshowconversion}prestashop>main_index_93cba07454f06a4a960172bbd6e2a435']
	//'Yes'
	= 'Tak';

$_MODULE['<{pshowconversion}prestashop>main_index_bafd7322c6e97d25b6299b5d6fe8920b']
	//'No'
	= 'Nie';

$_MODULE['<{pshowconversion}prestashop>main_index_46d8d089fc37331b310b8b304f12547b']
	//'Enter API Secret'
	= 'Wprowadź sekret API';

$_MODULE['<{pshowconversion}prestashop>main_index_0c23526210eacbaa290222fef406efef']
	//'An API Secret that is generated through the Google Analytics UI.'
	= 'Sekret API generowany za pośrednictwem interfejsu użytkownika Google Analytics.';

$_MODULE['<{pshowconversion}prestashop>main_index_a8a835c388d8c11dae08d63663bff629']
	//'To create a new secret, navigate in the Google Analytics UI to:'
	= 'Aby utworzyć nowy klucz tajny, przejdź w interfejsie użytkownika Google Analytics do:';

$_MODULE['<{pshowconversion}prestashop>main_index_415da365887dbc124abb91fd6a52700e']
	//'For proper operation of the function, it is required to add this URL as a CRON task:'
	= 'Do prawidłowego działania funkcji wymagane jest dodanie tego adresu URL jako zadania CRON:';

$_MODULE['<{pshowconversion}prestashop>main_index_9f2e6ea101cd82676f6b065cbf5de4ed']
	//'Example of CRON job running every 15 minutes:'
	= 'Przykład zadania CRON uruchamianego co 15 minut:';

$_MODULE['<{pshowconversion}prestashop>main_index_82bab87b4226275dbb6496e93a29f08c']
	//'This CRON job sends only orders from the current day, so it is recommended to run this task a few times a day and once more time a few minutes before midnight.'
	= 'To zadanie CRON wysyła tylko zlecenia z bieżącego dnia, więc zaleca się uruchamianie tego zadania kilka razy dziennie i jeszcze raz kilka minut przed północą.';

$_MODULE['<{pshowconversion}prestashop>main_index_546780d4d8e2a148e1a1f8c48b179e35']
	//'Last execution:'
	= 'Ostatnia egzekucja:';

$_MODULE['<{pshowconversion}prestashop>main_index_7030e293fa4917e5c8eb30a17b6592d7']
	//'The CRON task was started today, so transactions are being sent.' mod='pshowconversion'} {l s='Last execution:'
	= 'Zadanie CRON zostało uruchomione dzisiaj, więc transakcje są wysyłane." mod="pshowconversion"} {l s=\'Last execution:';

$_MODULE['<{pshowconversion}prestashop>main_index_7c5e0522512659e8274ff77c7923e1b0']
	//'Click to show instructions for CRON task'
	= 'Kliknij, aby wyświetlić instrukcje dla zadania CRON';

$_MODULE['<{pshowconversion}prestashop>main_index_d85458927583af395fe41116107c56bf']
	//'When and how do you want to send orders to Google Analytics?'
	= 'Kiedy i w jaki sposób chcesz wysyłać zamówienia do Google Analytics?';

$_MODULE['<{pshowconversion}prestashop>main_index_fe3e8e6121db09d02407289cd18a89ee']
	//'Send order immediately when order status is changed'
	= 'Wyślij zamówienie natychmiast po zmianie jego statusu';

$_MODULE['<{pshowconversion}prestashop>main_index_8e5d239e1aea5827ed17be735ea6239e']
	//'(additional configuration not required)'
	= '(dodatkowa konfiguracja nie jest wymagana)';

$_MODULE['<{pshowconversion}prestashop>main_index_ba363b07681f85921a2596bcee5337bf']
	//'I want to set up CRON task which will send orders'
	= 'Chcę skonfigurować zadanie CRON, które będzie wysyłać zamówienia';

$_MODULE['<{pshowconversion}prestashop>main_index_a3f6834efe23a59463728bd342c3675e']
	//'(you will have to add CRON job, details will be shown after submit this form)'
	= '(będziesz musiał dodać zadanie CRON, szczegóły zostaną wyświetlone po przesłaniu tego formularza)';

$_MODULE['<{pshowconversion}prestashop>main_index_84cfe895fbf2c71fb0fb7ced7ab63f88']
	//'(recommended option)'
	= '(opcja zalecana)';

$_MODULE['<{pshowconversion}prestashop>main_index_5914153af1e3cf6b573ebb524752505d']
	//'Which prices should be sent to Google Analytics?'
	= 'Które ceny powinny być wysyłane do Google Analytics?';

$_MODULE['<{pshowconversion}prestashop>main_index_2e7fffa720fc385b498def0fd9063138']
	//'Send product prices'
	= 'Wyślij ceny produktów';

$_MODULE['<{pshowconversion}prestashop>main_index_86ea09ffb4a5bb157cad1999dee33ab3']
	//'When:'
	= 'Kiedy:';

$_MODULE['<{pshowconversion}prestashop>main_index_4657ba03b2f9b82027275ddd56cd841d']
	//'Send profit from sales'
	= 'Wyślij zysk ze sprzedaży';

$_MODULE['<{pshowconversion}prestashop>main_index_86ea09ffb4a5bb157cad1999dee33ab3']
	//'When:'
	= 'Kiedy:';

$_MODULE['<{pshowconversion}prestashop>main_index_e7d31cb91684919c653f81e773cdaa37']
	//'Send net prices instead of gross'
	= 'Wysyłaj ceny netto zamiast brutto';

$_MODULE['<{pshowconversion}prestashop>main_index_93cba07454f06a4a960172bbd6e2a435']
	//'Yes'
	= 'Tak';

$_MODULE['<{pshowconversion}prestashop>main_index_bafd7322c6e97d25b6299b5d6fe8920b']
	//'No'
	= 'Nie';

$_MODULE['<{pshowconversion}prestashop>main_index_e5114c4b69585ba5883d456a74c1cd5d']
	//'Log level'
	= 'Poziom dziennika';

$_MODULE['<{pshowconversion}prestashop>main_index_a59725ab4ac350ab01e68eef03046ee8']
	//'High - debug mode, allows to read response from GA'
	= 'Wysoki - tryb debugowania, pozwala odczytać odpowiedź z GA';

$_MODULE['<{pshowconversion}prestashop>main_index_b6d40f4403d59850284e73f7f7908ffa']
	//'Medium - save every GA connection data to log'
	= 'Średni - zapisuj dane każdego połączenia GA w dzienniku';

$_MODULE['<{pshowconversion}prestashop>main_index_a46c9f7ffd6a631c4821a6d6d807ab6e']
	//'Low - save only orders to log'
	= 'Niski - zapisuj tylko zamówienia w dzienniku';

$_MODULE['<{pshowconversion}prestashop>main_index_b411cd4cdc7aa4994ffd01eedd6ad660']
	//'Disabled - nothing will be saved to log'
	= 'Wyłączone - nic nie zostanie zapisane w dzienniku';

$_MODULE['<{pshowconversion}prestashop>main_index_f6ec827e495a40f0c63797ebf7a6e411']
	//'Expiration of traffic sources'
	= 'Wygaśnięcie źródeł ruchu';

$_MODULE['<{pshowconversion}prestashop>main_index_640fd0cc0ffa0316ae087652871f4486']
	//'minutes'
	= 'minuty';

$_MODULE['<{pshowconversion}prestashop>main_index_4bc3e748e702eeb40baa605f952db035']
	//'After this time, sources not assigned to any order will be deleted.'
	= 'Po tym czasie źródła nieprzypisane do żadnego zamówienia zostaną usunięte.';

$_MODULE['<{pshowconversion}prestashop>main_index_7e8ecfcc3902e65d60cef4145ac6f879']
	//'Default = 1440'
	= 'Domyślnie = 1440';

$_MODULE['<{pshowconversion}prestashop>main_index_32f343edb9facee8ac5d40c798aeb61c']
	//'Anonymize customer IP address'
	= 'Anonimizuj adres IP klienta';

$_MODULE['<{pshowconversion}prestashop>main_index_93cba07454f06a4a960172bbd6e2a435']
	//'Yes'
	= 'Tak';

$_MODULE['<{pshowconversion}prestashop>main_index_bafd7322c6e97d25b6299b5d6fe8920b']
	//'No'
	= 'Nie';

$_MODULE['<{pshowconversion}prestashop>main_index_cce4bf9bf08c0c51e84f3ce1aec91dac']
	//'Select order states to send transaction to Google Analytics'
	= 'Wybierz stan zamówienia, aby wysłać transakcję do Google Analytics';

$_MODULE['<{pshowconversion}prestashop>main_index_f05e9d4098c391ecc3d5232515296f90']
	//'Select order states to withdraw transaction from Google Analytics'
	= 'Wybierz stan zamówienia, aby wycofać transakcję z Google Analytics';

$_MODULE['<{pshowconversion}prestashop>main_index_c9cc8cce247e49bae79f15173ce97354']
	//'Save'
	= 'Oszczędzaj';

$_MODULE['<{pshowconversion}prestashop>main_index_104415ac27267e30eae82dd79f9f3796']
	//'When deactivated, the module will not send shipping cost information to GA4.'
	= 'Gdy nieaktywne, moduł nie będzie wysyłał informacji dotyczących kosztów wysyłki do GA4.';

$_MODULE['<{pshowconversion}prestashop>main_index_227112446102dc0a53bd126a708dcbc9']
	//'Include shipping cost in transaction data'
	= 'Uwzględniaj koszta wysyłki zamówień w danych o transakcji';


// *****
// /views/templates/admin/main_log.tpl
// ***

$_MODULE['<{pshowconversion}prestashop>main_log_d48c98523eb6ec325ce7c085a7f595cb']
	//'Log list'
	= 'Lista dzienników';


// *****
// /views/templates/admin/main_oauth.tpl
// ***

$_MODULE['<{pshowconversion}prestashop>main_oauth_1a11db3d2781e8ee1401eab17b296b6a']
	//'Module settings'
	= 'Ustawienia modułu';

$_MODULE['<{pshowconversion}prestashop>main_oauth_1eec53e632bee0c1c3487d02c4e87dfb']
	//'Currently Reporting API is used only to check that transactions were sent and exists in the Google Analytics.'
	= 'Obecnie Reporting API służy jedynie do sprawdzania, czy transakcje zostały wysłane i istnieją w Google Analytics.';

$_MODULE['<{pshowconversion}prestashop>main_oauth_aab2b63f729e314cb58a61b125717011']
	//'Click here to watch video how to configure Reporting API in PShowConversion'
	= 'Kliknij tutaj, aby obejrzeć wideo jak skonfigurować API raportowania w PShowConversion';

$_MODULE['<{pshowconversion}prestashop>main_oauth_f359ed09941633507992d524e0d43566']
	//'Current status of the integration:'
	= 'Aktualny stan integracji:';

$_MODULE['<{pshowconversion}prestashop>main_oauth_2ff498abf55c3d8a99cf9cde047c935c']
	//'Missing client secret and/or client ID'
	= 'Brakujący klucz tajny klienta i/lub identyfikator klienta';

$_MODULE['<{pshowconversion}prestashop>main_oauth_c6bffd92b411f5ef2a596de011179c08']
	//'Missing view ID'
	= 'Brakujący identyfikator widoku';

$_MODULE['<{pshowconversion}prestashop>main_oauth_9214ee39011ef0b425792af9ef09b687']
	//'Waiting for authorization'
	= 'Oczekiwanie na autoryzację';

$_MODULE['<{pshowconversion}prestashop>main_oauth_07ca5050e697392c9ed47e6453f1453f']
	//'Completed'
	= 'Zakończone';

$_MODULE['<{pshowconversion}prestashop>main_oauth_d828967ee3543c34c52c99fbb7019730']
	//'How to create new credentials?'
	= 'Jak utworzyć nowe poświadczenia?';

$_MODULE['<{pshowconversion}prestashop>main_oauth_7f0b25ba8e1a5c04ca7a2cb22b685b92']
	//'1. Open Google Credentials page'
	= '1. Otwórz stronę Poświadczenia Google';

$_MODULE['<{pshowconversion}prestashop>main_oauth_242b15bf8966bba44cd73f1b7b453d9e']
	//'3. Fill the form using data below:'
	= '3. Wypełnij formularz korzystając z poniższych danych:';

$_MODULE['<{pshowconversion}prestashop>main_oauth_31e5862248cc3c3993c6435c965b4e20']
	//'- Application type: Web application'
	= '- Typ aplikacji: Aplikacja internetowa';

$_MODULE['<{pshowconversion}prestashop>main_oauth_1a11528fd030a97450ff453950b13fad']
	//'- Name: PShowConversion'
	= '- Nazwa: PShowConversion';

$_MODULE['<{pshowconversion}prestashop>main_oauth_04e8493f2d8b3cf02041017d459e4a22']
	//'4. Copy client ID, client secret and paste in the module configuration below'
	= '4. Skopiuj identyfikator klienta, sekret klienta i wklej w konfiguracji modułu poniżej';

$_MODULE['<{pshowconversion}prestashop>main_oauth_76525f0f34b48475e5ca33f71d296f3b']
	//'Client ID'
	= 'Identyfikator klienta';

$_MODULE['<{pshowconversion}prestashop>main_oauth_734082edf44417dd19cc65943aa65c36']
	//'Client Secret'
	= 'Tajemnica klienta';

$_MODULE['<{pshowconversion}prestashop>main_oauth_9e4024c454c2d0573a072e0ee989a6cd']
	//'How to get view ID?'
	= 'Jak uzyskać identyfikator widoku?';

$_MODULE['<{pshowconversion}prestashop>main_oauth_f647d4ebffa9abadc8f4a4d3e19f32ce']
	//'1. Open https://analytics.google.com'
	= '1. Otwórz https://analytics.google.com';

$_MODULE['<{pshowconversion}prestashop>main_oauth_2251815e766e03827fc5a07f81fc7c18']
	//'3. Copy view ID and paste in the module configuration below'
	= '3. Skopiuj identyfikator widoku i wklej go w poniższej konfiguracji modułu';

$_MODULE['<{pshowconversion}prestashop>main_oauth_f35ac60b4a12dc8f045f1b185bf5d959']
	//'View ID'
	= 'Wyświetl identyfikator';

$_MODULE['<{pshowconversion}prestashop>main_oauth_72252e76c903624df03f2bbf29adb19f']
	//'How to authorize access?'
	= 'Jak autoryzować dostęp?';

$_MODULE['<{pshowconversion}prestashop>main_oauth_4cd5683e8f48b78092bd5d5b9c3c88f9']
	//'1. Click on the authorization button below'
	= '1. Kliknij przycisk autoryzacji poniżej';

$_MODULE['<{pshowconversion}prestashop>main_oauth_6546a644f7b407ada607596da993b777']
	//'2. Log into Google account which has access to your Google Analytics page'
	= '2. Zaloguj się na konto Google, które ma dostęp do Twojej strony Google Analytics.';

$_MODULE['<{pshowconversion}prestashop>main_oauth_9cd8a2455b1839ff98ef70c05b9b5983']
	//'Authorization'
	= 'Autoryzacja';

$_MODULE['<{pshowconversion}prestashop>main_oauth_4f9652f1ef3a31e093edf76696bc1777']
	//'Enter client ID, client secret and view ID before authorization'
	= 'Wprowadź identyfikator klienta, klucz tajny klienta i identyfikator widoku przed autoryzacją.';

$_MODULE['<{pshowconversion}prestashop>main_oauth_76111020df639dfd74affc8cfb80c8f7']
	//'Click here to authorize access using Google account'
	= 'Kliknij tutaj, aby autoryzować dostęp za pomocą konta Google';

$_MODULE['<{pshowconversion}prestashop>main_oauth_07ca5050e697392c9ed47e6453f1453f']
	//'Completed'
	= 'Zakończone';

$_MODULE['<{pshowconversion}prestashop>main_oauth_c9cc8cce247e49bae79f15173ce97354']
	//'Save'
	= 'Oszczędzaj';

$_MODULE['<{pshowconversion}prestashop>main_oauth_449e9ff17ea08c39443fb3b4b49f79da']
	//'How to configure Reporting API in PShowConversion'
	= 'Jak skonfigurować API raportowania w PShowConversion?';


// *****
// /views/templates/admin/main_multistore.tpl
// ***

$_MODULE['<{pshowconversion}prestashop>main_multistore_c6e86f49ff01f9d0ff4363377cb1112b']
	//'Multistore settings'
	= 'Ustawienia wielu sklepów';

$_MODULE['<{pshowconversion}prestashop>main_multistore_a7b092545c566cdb78596753e43967d6']
	//'You must switch to single shop context to configure this module if you do not have multistore addon.'
	= 'Musisz przełączyć się do kontekstu pojedynczego sklepu, aby skonfigurować ten moduł, jeśli nie masz dodatku do wielu sklepów.';

$_MODULE['<{pshowconversion}prestashop>main_multistore_0c9e6df7f75a5c0b3de5c8ae5f54a4b7']
	//'To deactivate this module in current shop and activate in other please switch shop in the top right corner.'
	= 'Aby dezaktywować ten moduł w bieżącym sklepie i aktywować w innym, przełącz sklep w prawym górnym rogu.';

$_MODULE['<{pshowconversion}prestashop>main_multistore_2cd3fb4b4501fa5f45a227a2d7b0f989']
	//'Enable module in current shop'
	= 'Włącz moduł w bieżącym sklepie';

$_MODULE['<{pshowconversion}prestashop>main_multistore_e2144a0beb1b88571aafbdb1114cf44b']
	//'and deactivate in other shops'
	= 'i dezaktywuj w innych sklepach';

$_MODULE['<{pshowconversion}prestashop>main_multistore_93cba07454f06a4a960172bbd6e2a435']
	//'Yes'
	= 'Tak';

$_MODULE['<{pshowconversion}prestashop>main_multistore_bafd7322c6e97d25b6299b5d6fe8920b']
	//'No'
	= 'Nie';

$_MODULE['<{pshowconversion}prestashop>main_multistore_c9cc8cce247e49bae79f15173ce97354']
	//'Save'
	= 'Oszczędzaj';


// *****
// /views/templates/admin/main_datalayer.tpl
// ***

$_MODULE['<{pshowconversion}prestashop>main_datalayer_1a11db3d2781e8ee1401eab17b296b6a']
	//'Module settings'
	= 'Ustawienia modułu';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_4f97fc8f000d2e253329151c49fc171d']
	//'Using dataLayer, the module sends events - for example, when a customer adds a product to the cart then the add_to_cart event is sent. Events are sent by the module to UA, GA4, GTM services - as long as their IDs are specified in the module in the corresponding tabs.'
	= 'Za pomocą dataLayer moduł wysyła zdarzenia - na przykład, gdy klient dodaje produkt do koszyka, wysyłane jest zdarzenie add_to_cart. Zdarzenia są wysyłane przez moduł do usług UA, GA4, GTM - o ile ich identyfikatory są określone w module w odpowiednich zakładkach.';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_c8750280b2b250ed575a215d5ba841bd']
	//'Google Tag Manager ID is required.'
	= 'Wymagany jest identyfikator Menedżera tagów Google.';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_a4ea91cd0d1ea33d8113457644dd6157']
	//'click here'
	= 'kliknij tutaj';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_5d9715ad9520e1a63bd1348eade45e20']
	//'Enable sending events with dataLayer'
	= 'Włącz wysyłanie zdarzeń za pomocą dataLayer';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_93cba07454f06a4a960172bbd6e2a435']
	//'Yes'
	= 'Tak';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_bafd7322c6e97d25b6299b5d6fe8920b']
	//'No'
	= 'Nie';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_7f77e3d7178f0b1979d13c101a456450']
	//'Enable debug mode'
	= 'Włącz tryb debugowania';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_93cba07454f06a4a960172bbd6e2a435']
	//'Yes'
	= 'Tak';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_bafd7322c6e97d25b6299b5d6fe8920b']
	//'No'
	= 'Nie';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_782b6f71b7799f7e9802ae4b20ef2ba7']
	//'When debug mode is active, all events sent by the module will be displayed in the browser console.'
	= 'Gdy tryb debugowania jest aktywny, wszystkie zdarzenia wysyłane przez moduł będą wyświetlane w konsoli przeglądarki.';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_35e0c11df959bc9376dbb20670e11c2a']
	//'Event name prefix (optional)'
	= 'Prefiks nazwy zdarzenia (opcjonalnie)';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_ae82b0212142a67d78324a5c86f3c044']
	//'Do not send data from GTM to GA4 if you have entered the GA4 identifier in the module configuration, otherwise events and transactions may be duplicated.'
	= 'Nie wysyłaj danych z GTM do GA4, jeśli wprowadziłeś identyfikator GA4 w konfiguracji modułu, w przeciwnym razie zdarzenia i transakcje mogą zostać zduplikowane.';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_9fa7e60147bc82b9610761e5bd183d6c']
	//'If you want to sent data from dataLayer to Google Analytics'
	= 'Jeśli chcesz przesłać dane z dataLayer do Google Analytics';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_c4fe859ac33d3d549b704f29e5807534']
	//'How it works?'
	= 'Jak to działa?';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_47398fce085cafdb0e06dcf9af6c1e5f']
	//'You can import container to'
	= 'Możesz zaimportować kontener do';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_081c768856e6d0a31d3a07c2c452ce9f']
	//'using configuration prepared by us.'
	= 'korzystając z przygotowanej przez nas konfiguracji.';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_1f0c3a64c456bb0646aee6fe292217ff']
	//'Download configuration file'
	= 'Pobierz plik konfiguracyjny';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_fc6d76fa34047ed17e89a4fdac8be965']
	//'...or you can setup everything manually in the '
	= '...lub możesz skonfigurować wszystko ręcznie w sekcji ';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_1030bf3d113fa4e4b0a5a40f7925b040']
	//' using these events: '
	= ' przy użyciu tych zdarzeń: ';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_e73cee64bda41845920da8f7232831fc']
	//'Enable Enhanced Ecommerce'
	= 'Włącz ulepszony handel elektroniczny';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_5a4a5535aae678bbc64d3e60a855520d']
	//'2. Enable \'e-commerce\' and \'enhanced e-commerce\''
	= '2. Włącz "e-commerce" i "rozszerzony e-commerce".';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_5102b077db593bcb5669609a1832e4d0']
	//'Configure checkout labeling (optional)'
	= 'Skonfiguruj etykietowanie kasy (opcjonalnie)';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_3b0823d46e62252c084447cae3ace5c9']
	//'1. Shopping cart'
	= '1. Koszyk';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_661f50dba2280440dfd2446646240063']
	//'2. Address'
	= '2. Adres';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_926a1b568f49d3ca5dd26285d09f3a28']
	//'3. Shipping'
	= '3. Wysyłka';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_3fe70635717e6d4946ef2194cb94dacb']
	//'4. Payment'
	= '4. Płatność';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_dc2e1eb66dee0f397eadeb86a79a67bd']
	//'5. Order confirmation'
	= '5. Potwierdzenie zamówienia';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_97cacaa64c1fd78de5e00f81998ad7be']
	//'6. Refund'
	= '6. Zwrot kosztów';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_47398fce085cafdb0e06dcf9af6c1e5f']
	//'You can import container to'
	= 'Możesz zaimportować kontener do';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_081c768856e6d0a31d3a07c2c452ce9f']
	//'using configuration prepared by us.'
	= 'korzystając z przygotowanej przez nas konfiguracji.';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_1f0c3a64c456bb0646aee6fe292217ff']
	//'Download configuration file'
	= 'Pobierz plik konfiguracyjny';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_46a53407942d704078d8e59149d95170']
	//'...or you can setup everything manually using instructions below'
	= '...lub możesz skonfigurować wszystko ręcznie, korzystając z poniższych instrukcji';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_44ff92f0bf5d4bfdb7966da80254a3cf']
	//'Add tags and triggers in the'
	= 'Dodaj tagi i wyzwalacze w sekcji';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_2deaee726cd31d9bbeac3aee65f48066']
	//'Every action (detail, impressions, checkout etc.) in this module uses events.'
	= 'Każda akcja (szczegóły, wyświetlenia, płatność itp.) w tym module wykorzystuje zdarzenia.';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_e7c3129d978d43a77be1ccf2ba4f1f24']
	//'Tag option for all actions:'
	= 'Opcja znacznika dla wszystkich akcji:';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_7b03df53ca5841e76c38f64bd7dccaab']
	//'Tag type : Universal Analytics'
	= 'Typ znacznika : Universal Analytics';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_2291a459343fcb0d12ff1e82d1ba7b8b']
	//'Track type : Event'
	= 'Typ toru : Wydarzenie';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_78aa0af3eb0c5425dfd54dd6ab1a7a62']
	//'Event Category: Ecommerce'
	= 'Kategoria wydarzenia: Ecommerce';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_dbf93db569f5ecee051cacccba80b106']
	//'Event Action: (enter action name)'
	= 'Akcja zdarzenia: (wprowadź nazwę akcji)';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_b9441e68536273c99008aa23bcada430']
	//'Non-interaction:'
	= 'Brak interakcji:';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_45db9cb32472513ea52f166bb38f4c30']
	//'true - for event action:'
	= 'true - dla akcji zdarzenia:';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_12565769bb42f1d273809dbcdf7a1a81']
	//'false - for event action:'
	= 'false - dla akcji zdarzenia:';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_f84dee2e59f4aa19bdf91b0536fe81fa']
	//'Enable Enhanced Ecommerce Features: true'
	= 'Włącz rozszerzone funkcje e-commerce: true';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_6d988e8e70ecb0a7dc5011bb5f714355']
	//'Use Data Layer: true'
	= 'Użyj warstwy danych: true';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_80be1ed05ca0037f16db83e97054c4fb']
	//'Trigger: event equals (enter action name)'
	= 'Wyzwalacz: zdarzenie równe (wprowadź nazwę akcji)';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_bd72c6a65f0086c4c12a886d643c47c4']
	//'For example, to catch checkout steps you must add new tag with options:'
	= 'Na przykład, aby przechwycić kroki kasy, musisz dodać nowy tag z opcjami:';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_7b03df53ca5841e76c38f64bd7dccaab']
	//'Tag type : Universal Analytics'
	= 'Typ znacznika : Universal Analytics';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_2291a459343fcb0d12ff1e82d1ba7b8b']
	//'Track type : Event'
	= 'Typ toru : Wydarzenie';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_78aa0af3eb0c5425dfd54dd6ab1a7a62']
	//'Event Category: Ecommerce'
	= 'Kategoria wydarzenia: Ecommerce';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_e6de0e0822d30f9f06a8180a7eec05b2']
	//'Event Action: Checkout'
	= 'Akcja wydarzenia: Checkout';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_b7c1d4f96bac9f27363db957b5b7609e']
	//'Non-interaction: true'
	= 'Brak interakcji: true';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_f84dee2e59f4aa19bdf91b0536fe81fa']
	//'Enable Enhanced Ecommerce Features: true'
	= 'Włącz rozszerzone funkcje e-commerce: true';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_6d988e8e70ecb0a7dc5011bb5f714355']
	//'Use Data Layer: true'
	= 'Użyj warstwy danych: true';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_1c850a75909dbaf6a380ad3ad87bdb7a']
	//'Trigger: event equals checkout'
	= 'Wyzwalacz: zdarzenie równe kasie';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_c7f150c89a82cdbc4bf0f226759c37a8']
	//'List of the actions (name and description):'
	= 'Lista działań (nazwa i opis):';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_f96ba6630520ca1fde1509fde801ec1f']
	//'How to add tags in the Google Tag Manager? (example for event: impressions)'
	= 'Jak dodać tagi w Menedżerze tagów Google (przykład dla zdarzenia: wyświetlenia)?';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_5d9715ad9520e1a63bd1348eade45e20']
	//'Enable sending events with dataLayer'
	= 'Włącz wysyłanie zdarzeń za pomocą dataLayer';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_93cba07454f06a4a960172bbd6e2a435']
	//'Yes'
	= 'Tak';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_bafd7322c6e97d25b6299b5d6fe8920b']
	//'No'
	= 'Nie';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_c9cc8cce247e49bae79f15173ce97354']
	//'Save'
	= 'Oszczędzaj';

$_MODULE['<{pshowconversion}prestashop>main_datalayer_25324dc519e55ea40b5b607256292f2a']
	//'List of events sent by dataLayer'
	= 'Lista zdarzeń wysłanych przez dataLayer';


// *****
// /views/templates/admin/send_index.tpl
// ***

$_MODULE['<{pshowconversion}prestashop>send_index_5165f697b480335d28ef92dc56491cc7']
	//'Send orders to Google Analytics'
	= 'Wysyłaj zamówienia do Google Analytics';

$_MODULE['<{pshowconversion}prestashop>send_index_43569e76a1242e7505c6e13e2590a2a0']
	//'Enter orders id separated by comma'
	= 'Wprowadź identyfikator zamówienia oddzielony przecinkiem';

$_MODULE['<{pshowconversion}prestashop>send_index_0a52730597fb4ffa01fc117d9e71e3a9']
	//'Example'
	= 'Przykład';

$_MODULE['<{pshowconversion}prestashop>send_index_73573a0dd8bc06013a7d54e2ff9ebf85']
	//'Orders will be sent with a date'
	= 'Zamówienia zostaną wysłane z datą';

$_MODULE['<{pshowconversion}prestashop>send_index_64f524859464c259da15f95aff929a44']
	//'Force sending'
	= 'Wymuś wysyłanie';

$_MODULE['<{pshowconversion}prestashop>send_index_2d624dec9fc025d4aefd858fe498dcba']
	//'Send transactions'
	= 'Wyślij transakcje';

$_MODULE['<{pshowconversion}prestashop>send_index_b0433be4669cc3d1169f75afefd904ae']
	//'Withdraw orders sent to Google Analytics'
	= 'Wycofaj zlecenia wysłane do Google Analytics';

$_MODULE['<{pshowconversion}prestashop>send_index_43569e76a1242e7505c6e13e2590a2a0']
	//'Enter orders id separated by comma'
	= 'Wprowadź identyfikator zamówienia oddzielony przecinkiem';

$_MODULE['<{pshowconversion}prestashop>send_index_0a52730597fb4ffa01fc117d9e71e3a9']
	//'Example'
	= 'Przykład';

$_MODULE['<{pshowconversion}prestashop>send_index_73573a0dd8bc06013a7d54e2ff9ebf85']
	//'Orders will be sent with a date'
	= 'Zamówienia zostaną wysłane z datą';

$_MODULE['<{pshowconversion}prestashop>send_index_64f524859464c259da15f95aff929a44']
	//'Force sending'
	= 'Wymuś wysyłanie';

$_MODULE['<{pshowconversion}prestashop>send_index_136b5afc612c0d5540a7954004ea6a96']
	//'Withdrawing a transaction does not mean its removal. Both the original transaction and the withdrawn one are included in the number of transactions.'
	= 'Wycofanie transakcji nie oznacza jej usunięcia. Zarówno pierwotna transakcja, jak i wycofana transakcja są wliczane do liczby transakcji.';

$_MODULE['<{pshowconversion}prestashop>send_index_2d624dec9fc025d4aefd858fe498dcba']
	//'Send transactions'
	= 'Wyślij transakcje';


// *****
// /views/templates/admin/main_ads.tpl
// ***

$_MODULE['<{pshowconversion}prestashop>main_ads_1a11db3d2781e8ee1401eab17b296b6a']
	//'Module settings'
	= 'Ustawienia modułu';

$_MODULE['<{pshowconversion}prestashop>main_ads_c2257083787769eceab8c801845a4553']
	//'Instead of entering conversion id below, you can use Google Tag Manager or link Google Ads account with the Google Analytics'
	= 'Zamiast wpisywać identyfikator konwersji poniżej, możesz użyć Menedżera tagów Google lub połączyć konto Google Ads z Google Analytics.';

$_MODULE['<{pshowconversion}prestashop>main_ads_01d954fb2edbf283d121f0651b04de83']
	//'Additional documentation'
	= 'Dodatkowa dokumentacja';

$_MODULE['<{pshowconversion}prestashop>main_ads_44ab6ccf0af9ad5ba044b6fae5057674']
	//'enter_google_ads_conversion_id'
	= 'enter_google_ads_conversion_id';

$_MODULE['<{pshowconversion}prestashop>main_ads_f8c9c7904e5fb5d045353a229bb0f982']
	//'enter_google_ads_conversion_label'
	= 'enter_google_ads_conversion_label';

$_MODULE['<{pshowconversion}prestashop>main_ads_c9cc8cce247e49bae79f15173ce97354']
	//'Save'
	= 'Oszczędzaj';


// *****
// /views/templates/admin/main_optimize.tpl
// ***

$_MODULE['<{pshowconversion}prestashop>main_optimize_1a11db3d2781e8ee1401eab17b296b6a']
	//'Module settings'
	= 'Ustawienia modułu';

$_MODULE['<{pshowconversion}prestashop>main_optimize_be44a4dde8f61a81b27acdcdade9c4a3']
	//'Enter Google Optimize id'
	= 'Wprowadź identyfikator Google Optimize';

$_MODULE['<{pshowconversion}prestashop>main_optimize_031a0cece38c4739df67f910dcabf1bd']
	//'Google Optimize'
	= 'Google Optimize';

$_MODULE['<{pshowconversion}prestashop>main_optimize_52d6c659b0e5194cc7677878815194e2']
	//'Google Analytics ID is required.'
	= 'Wymagany jest identyfikator Google Analytics.';

$_MODULE['<{pshowconversion}prestashop>main_optimize_ba674ae5b567dc6e6f70fc8ad9619248']
	//'Use it only when needed, the module performs better when Google Optimize is turned off.'
	= 'Używaj go tylko wtedy, gdy jest to konieczne, moduł działa lepiej, gdy Google Optimize jest wyłączony.';

$_MODULE['<{pshowconversion}prestashop>main_optimize_7a66e563bde6620c4188f2d35ad74844']
	//'Optimize plugin is served via Tag Manager'
	= 'Wtyczka Optimize jest obsługiwana przez Menedżera tagów';

$_MODULE['<{pshowconversion}prestashop>main_optimize_5d3ee00c373c5c4ed47a761939e94b76']
	//'more info'
	= 'więcej informacji';

$_MODULE['<{pshowconversion}prestashop>main_optimize_c30ee47dc0e62d783700e38cc8c2ed46']
	//'How to check is Google Optimize working?'
	= 'Jak sprawdzić, czy Google Optimize działa?';

$_MODULE['<{pshowconversion}prestashop>main_optimize_5ae907529df7af46c12e2731f7f88818']
	//'1. Install the Google Chrome browser extension:'
	= '1. Zainstaluj rozszerzenie przeglądarki Google Chrome:';

$_MODULE['<{pshowconversion}prestashop>main_optimize_664df119aa1329966b494b2389fc7ab9']
	//'2. Go to the address of your store in your browser.'
	= '2. Przejdź do adresu swojego sklepu w przeglądarce.';

$_MODULE['<{pshowconversion}prestashop>main_optimize_f2eca076027732e609c6bfe05e13cff7']
	//'3. In the installed extension, press the \'Enable\' button.'
	= '3. W zainstalowanym rozszerzeniu naciśnij przycisk "Włącz".';

$_MODULE['<{pshowconversion}prestashop>main_optimize_9d8cc0c19f84ff9925609fa9f9214b7f']
	//'4. Refresh the website.'
	= '4. Odśwież stronę internetową.';

$_MODULE['<{pshowconversion}prestashop>main_optimize_74745a388b16958288bc0eb7e4981909']
	//'Why code labeled \'Google Analytics\' is red?'
	= 'Dlaczego kod oznaczony jako "Google Analytics" jest czerwony?';

$_MODULE['<{pshowconversion}prestashop>main_optimize_1680475827a0bd4d7391e40021fa04d4']
	//'This module do not use JavaScript tracking code because it sends data to Google Analytics on the server side.' mod='pshowconversion'} {l s='JavaScript tracking code is required for Google Optimize.' mod='pshowconversion'} {l s='Google Analytics must be displayed in red to not duplicate data in the statistics.'
	= 'Ten moduł nie używa kodu śledzenia JavaScript, ponieważ wysyła dane do Google Analytics po stronie serwera.\' mod=\'pshowconversion\'} {l s=\'Kod śledzenia JavaScript jest wymagany dla Google Optimize.\' mod=\'pshowconversion\'} {l s=\'Google Analytics musi być wyświetlane na czerwono, aby nie powielać danych w statystykach.';

$_MODULE['<{pshowconversion}prestashop>main_optimize_c9cc8cce247e49bae79f15173ce97354']
	//'Save'
	= 'Oszczędzaj';


// *****
// /views/templates/hook/displayBackOfficeOrderAdd.tpl
// ***

$_MODULE['<{pshowconversion}prestashop>displaybackofficeorderadd_b171b627de85e0268f236fca7f087060']
	//'Source of the order'
	= 'Źródło zamówienia';

$_MODULE['<{pshowconversion}prestashop>displaybackofficeorderadd_7a52e36bf4a1caa031c75a742fb9927a']
	//'Powered by'
	= 'Zasilany przez';

$_MODULE['<{pshowconversion}prestashop>displaybackofficeorderadd_f31bbdd1b3e85bccd652680e16935819']
	//'Source'
	= 'Źródło';

$_MODULE['<{pshowconversion}prestashop>displaybackofficeorderadd_87f8a6ab85c9ced3702b4ea641ad4bb5']
	//'Medium'
	= 'Średni';

